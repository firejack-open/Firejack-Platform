//
//  GWEnumConstraint.h
//  Prometheus
//
//  Created by mjr on 7/3/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWConstraint.h"
#import "GWRuleParameter.h"

@interface GWEnumConstraint : GWConstraint

@property (nonatomic, retain) NSArray *values;

@end
