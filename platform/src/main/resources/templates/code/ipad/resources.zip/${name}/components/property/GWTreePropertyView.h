//
//  GWTreePropertyView.h
//  Prometheus
//
//  Created by mjr on 7/10/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWObjectPropertyView.h"
#import "GWEntityViewController.h"

@interface GWTreePropertyView : GWObjectPropertyView {
    UIButton *_child;
}

@end
