//
//  OFTreeNode.m
//  Prometheus
//
//  Created by Eugene Maystrenko on 7/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "OFTreeNode.h"

@implementation OFTreeNode

- (id) initWithDictionary:(NSDictionary *) dictionary {
    if (self = [super initWithDictionary:dictionary]) {
		self.parentId = [Util get:dictionary key:@"parentId"];       
	}
	return self;
}

- (NSMutableDictionary *) dictionary {
    NSMutableDictionary *dic = [super dictionary];
    
    [Util add:dic value:self.parentId key:@"parentId"];
    
    return dic;
}


- (void) dealloc {
    [_parentId release];
    [super dealloc];
}

@end
