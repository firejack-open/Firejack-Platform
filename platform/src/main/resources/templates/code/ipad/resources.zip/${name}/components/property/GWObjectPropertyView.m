//
//  GWObjectPropertyView.m
//  Prometheus
//
//  Created by mjr on 6/26/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWObjectPropertyView.h"

@implementation GWObjectPropertyView

- (id) initWithFrame:(CGRect) frame property:(GWProperty *) property {
    self = [super initWithFrame:RectSetHeight(frame, 75) property:property];
    if (self) {
        _multiValue = NO;
    }
    return self;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    [self.mainView endEditing:YES];
    self.selected = !self.selected;
    return NO;
}

- (void) setSelected:(BOOL) selected {
    [super setSelected:selected];
    
    if (selected) {
        [self.sliderView reload];
    }
    
    [self.sliderView show];
}

- (void) setValue:(id) value {
    [super setValue:value];
    if (_property.type == GWPropertyTypeObject || _property.type == GWPropertyTypeTree)
        [self addReference:value];

}

- (void) removeObject:(id) value {
    [super removeObject:value];
    [self removeReference:value];
}

@end
