//
//  GWImagePropertyView.m
//  Prometheus
//
//  Created by mjr on 6/26/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWImagePropertyView.h"

@implementation GWImagePropertyView

- (id) initWithFrame:(CGRect) frame property:(GWProperty *) property {
    self = [super initWithFrame:RectSetHeight(frame, 115) property:property];
    if (self) {
        _imagePickerView = [[GWImagePickerView alloc] initWithFrame:CGRectMake(0, 25, 90, 90)];
        [self addSubview:_imagePickerView];
        [_imagePickerView release];
    }
    return self;
}

- (void) prepare {
    [super prepare];
    
    _imagePickerView.delegate = self.delegate;
    _imagePickerView.lookup = [_property stringValue:self.entity];
}

- (void) prePersist {
    if ([self.delegate respondsToSelector:@selector(prepersist:property:userObject:)]) {
        [self.delegate prepersist:self property:_property userObject:_imagePickerView];
    }
}

@end
