//
//  GWTextPropertyView.h
//  Prometheus
//
//  Created by mjr on 6/26/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWPropertyView.h"

@interface GWTextPropertyView : GWPropertyView<UITextViewDelegate> {
    UITextView *_textView;
}

@end
