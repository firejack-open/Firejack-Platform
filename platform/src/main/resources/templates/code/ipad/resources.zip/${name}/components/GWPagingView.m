//
//  GWPagingView.m
//  Prometheus
//
//  Created by Администратор on 4/1/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWPagingView.h"

static NSString *numRegex = @"|[0-9]+";

@implementation GWPagingView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _offset = 0;
        CGFloat width = frame.size.width;
        CGFloat center = width/2;
        
        UIImage *active = [UIImage stretchableImageNamed:@"pg_button_ca" left:@"pg_button_la" rigth:@"pg_button_ra" toSize:CGSizeMake(80, 30)];
        UIImage *inactive = [UIImage stretchableImageNamed:@"pg_button_cf" left:@"pg_button_lf" rigth:@"pg_button_rf" toSize:CGSizeMake(80, 30)];
        
        UIImageView *background = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"pg_background"]];
        [self addSubview:background];
        [background release];
        
         _first = [[UIButton alloc] initWithFrame:CGRectMake(10, 9, 80, 30)];
         _first.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:12];
         _first.titleLabel.textColor = [UIColor whiteColor];
         _first.titleLabel.layer.shadowColor = UIColorFromHex(0x1F2933).CGColor;
         _first.titleLabel.layer.shadowOffset = CGSizeMake(0, -1);
        [_first setTitle:@"First Page" forState:UIControlStateNormal];
        [_first addTarget:self action:@selector(change:) forControlEvents:UIControlEventTouchUpInside];
        [_first setBackgroundImage:inactive forState:UIControlStateNormal];
        [_first setBackgroundImage:active forState:UIControlStateSelected];
        [self addSubview:_first];
        [_first release];
        
         _prev = [[UIButton alloc] initWithFrame:CGRectMake(center - 160, 9, 80, 30)];
         _prev.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:12];
         _prev.titleLabel.textColor = [UIColor whiteColor];
         _prev.titleLabel.layer.shadowColor = UIColorFromHex(0x1F2933).CGColor;
         _prev.titleLabel.layer.shadowOffset = CGSizeMake(0, -1);
        [_prev setTitle:@"Prev Page" forState:UIControlStateNormal];
        [_prev addTarget:self action:@selector(change:) forControlEvents:UIControlEventTouchUpInside];
        [_prev setBackgroundImage:inactive forState:UIControlStateNormal];
        [_prev setBackgroundImage:active forState:UIControlStateSelected];
        [self addSubview:_prev];
        [_prev release];
        
        UILabel *page = [[UILabel alloc] initWithFrame:CGRectMake(center - 65, 9, 40, 30)];
        page.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:15];
        page.textColor = UIColorFromHex(0xD9EFFFE);
        page.layer.shadowColor = UIColorFromHex(0x1F2933).CGColor;
        page.layer.shadowOffset = CGSizeMake(0, -1);
        page.text = @"Page";
        page.backgroundColor = [UIColor clearColor];
        page.textColor = [UIColor whiteColor];
        [self addSubview:page];
        [page release];

        _current = [[GWTextFieldView alloc] initWithFrame:CGRectMake(center - 20, 9, 40, 30)];
        _current.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:15];
        _current.textColor = UIColorFromHex(0x7F7F7F);
        _current.keyboardType = UIKeyboardTypeNumberPad;
        _current.returnKeyType = UIReturnKeyDone;
        _current.backgroundColor = [UIColor whiteColor];
        _current.delegate = self;
        _current.textAlignment = NSTextAlignmentCenter;
        _current.contentHorizontalAlignment = UIControlContentHorizontalAlignmentCenter;
        _current.dy = 5;
        [self addSubview:_current];
        [_current release];
        
        _of = [[UILabel alloc] initWithFrame:CGRectMake(center + 30, 9, 60, 30)];
        _of.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:15];
        _of.textColor = UIColorFromHex(0xD9EFFFE);
        _of.layer.shadowColor = UIColorFromHex(0x1F2933).CGColor;
        _of.layer.shadowOffset = CGSizeMake(0, -1);
        _of.text = @"of 1";
        _of.backgroundColor = [UIColor clearColor];
        _of.textColor = [UIColor whiteColor];
        [self addSubview:_of];
        [_of release];
 
         _next = [[UIButton alloc] initWithFrame:CGRectMake(center + 80, 9, 80, 30)];
         _next.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:12];
         _next.titleLabel.textColor = [UIColor whiteColor];
         _next.titleLabel.layer.shadowColor = UIColorFromHex(0x1F2933).CGColor;
         _next.titleLabel.layer.shadowOffset = CGSizeMake(0, -1);
        [_next setTitle:@"Next Page" forState:UIControlStateNormal];
        [_next addTarget:self action:@selector(change:) forControlEvents:UIControlEventTouchUpInside];
        [_next setBackgroundImage:inactive forState:UIControlStateNormal];
        [_next setBackgroundImage:active forState:UIControlStateSelected];
        [self addSubview:_next];
        [_next release];
        
         _last = [[UIButton alloc] initWithFrame:CGRectMake(width - 90, 9, 80, 30)];
         _last.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:12];
         _last.titleLabel.textColor = [UIColor whiteColor];
         _last.titleLabel.layer.shadowColor = UIColorFromHex(0x1F2933).CGColor;
         _last.titleLabel.layer.shadowOffset = CGSizeMake(0, -1);
        [_last setTitle:@"Last Page" forState:UIControlStateNormal];
        [_last addTarget:self action:@selector(change:) forControlEvents:UIControlEventTouchUpInside];
        [_last setBackgroundImage:inactive forState:UIControlStateNormal];
        [_last setBackgroundImage:active forState:UIControlStateSelected];
        [self addSubview:_last];
        [_last release];
        
        self.backgroundColor = [UIColor blueColor];
    }
    return self;
}

- (void)dealloc {
    [_total release];
    [_limit release];
    [super dealloc];
}

- (void)setLimit:(NSNumber *)limit {
    [_limit release];
    _limit = [limit retain];

    if (_total) {
        _page = [_total intValue] / [_limit intValue];
        _page = [_total intValue] % [_limit intValue] == 0 ? _page : ++_page;
        _current.text = [NSString stringWithFormat:@"%d", _offset / [_limit intValue] + 1];
        _of.text = [NSString stringWithFormat:@"of %d", _page];
    }
}

- (void) setTotal:(NSNumber *) total {
    [_total release];
    _total = [total retain];
    
    if (_limit) {
        _page = [_total intValue] / [_limit intValue];
        _page = [_total intValue] % [_limit intValue] == 0 ? _page : ++_page;
        _current.text = [NSString stringWithFormat:@"%d", _offset / [_limit intValue] + 1];
        _of.text = [NSString stringWithFormat:@"of %d", _page];
        
        [self validateButton];
        if (_offset != 0 && _offset == [_total intValue]) {
            _offset -= [_limit intValue];
            [self reload];
        }
    }
}

- (void) reload {
    if (_limit) {
        [_delegate paging:self offset:@(_offset) limit:_limit];
    }
}

- (void) change:(UIButton *) sender {
    if (![_delegate respondsToSelector:@selector(paging:offset:limit:)]) {
        return;
    }
    
    int total = [_total intValue];
    int limit = [_limit intValue];
    int last_offset = total - total % limit;
    
    if (sender == _first) {
        _offset = 0;
    } else if (sender == _prev) {
        _offset = MAX(0, _offset - limit);
    } else if (sender == _next) {
        _offset += limit;
    } else if (sender == _last) {
        _offset = last_offset;
    }
    
    [self validateButton];
    [_delegate paging:self offset:@(_offset) limit:_limit];
}

- (void) validateButton {
    int total = [_total intValue];
    int limit = [_limit intValue];
    
    _first.enabled = _offset != 0;
    _prev.enabled = _offset != 0;
    _next.enabled = total > _offset + limit;
    _last.enabled = total > _offset + limit;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    CGRect frame = self.frame;
    frame.origin.y -= 354;
    self.frame = frame;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    CGRect frame = self.frame;
    frame.origin.y += 354;
    self.frame = frame;
    
    if ([textField.text isEqualToString:@""]) {
        textField.text = [NSString stringWithFormat:@"%d", _offset / [_limit intValue] + 1];
    } else {
        _offset = ([textField.text intValue] - 1) * [_limit intValue];
        
        [self validateButton];
        [_delegate paging:self offset:@(_offset) limit:_limit];
    }
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    return [textField resignFirstResponder];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSPredicate *numTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", numRegex];
    if (![numTest evaluateWithObject:string]) return NO;
    
    NSString *text = textField.text;
    int page = [[text stringByReplacingCharactersInRange:range withString:string] intValue];
    
    return page <= _page;
}

@end
