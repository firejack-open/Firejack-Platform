//
//  GWPropertyViewFactory.h
//  Prometheus
//
//  Created by mjr on 6/25/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GWProperty.h"
#import "GWFieldPropertyView.h"
#import "GWTextPropertyView.h"
#import "GWPasswordPropertyView.h"
#import "GWPhoneNumberPropertyView.h"
#import "GWSSNPropertyView.h"
#import "GWImagePropertyView.h"
#import "GWDatePropertyView.h"
#import "GWObjectPropertyView.h"
#import "GWEnumPropertyView.h"
#import "GWFlagPropertyView.h"
#import "GWAssociationPropertyView.h"
#import "GWTreePropertyView.h"

@interface GWPropertyViewFactory : NSObject

+ (id) createPropertyView:(CGRect) frame property:(GWProperty *) property;

@end
