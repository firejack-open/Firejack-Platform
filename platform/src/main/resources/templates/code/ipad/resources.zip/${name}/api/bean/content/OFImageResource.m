//
//  OFImageResource.m
//  Prometheus
//
//  Created by Eugene Maystrenko on 7/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "OFImageResource.h"

@implementation OFImageResource

- (id) initWithDictionary:(NSDictionary *) dictionary {
    if (self = [super initWithDictionary:dictionary]) {
        self.resourceVersion = [Util getObject:dictionary key:@"resourceVersion" bean:[OFImageResourceVersion class]];
	}
	return self;
}

- (NSMutableDictionary *) dictionary {
    NSMutableDictionary *dic = [super dictionary];
    
    [Util add:dic value:[self.resourceVersion dictionary] key:@"resourceVersion"];
    
    return dic;
}

- (void) dealloc {
    [_resourceVersion release];
    [super dealloc];
}

@end
