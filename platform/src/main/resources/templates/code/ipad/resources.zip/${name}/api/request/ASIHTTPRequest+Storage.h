//
//  ASIHTTPRequest+Storage.h
//  Prometheus
//
//  Created by mjr on 5/7/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "ASIHTTPRequest.h"

@interface ASIHTTPRequest (Storage)

@property (nonatomic, retain) NSObject *transient;

@end
