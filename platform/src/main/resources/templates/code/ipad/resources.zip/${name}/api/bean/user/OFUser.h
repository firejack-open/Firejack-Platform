//
//  OFUser.h
//  Prometheus
//
//  Created by Eugene Maystrenko on 6/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "GWEntity.h"

@interface OFUser : GWEntity

@property (nonatomic, retain) NSString *username;
@property (nonatomic, retain) NSString *firstName;
@property (nonatomic, retain) NSString *lastName;
@property (nonatomic, retain) NSString *password;
@property (nonatomic, retain) NSString *email;
@property (nonatomic, retain) NSString *avatarResourceLookup;
@property (nonatomic, retain) NSString *temporaryFile;

@end
