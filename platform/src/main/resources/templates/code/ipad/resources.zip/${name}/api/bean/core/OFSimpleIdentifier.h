//
//  OFSimpleIdentifier.h
//  Prometheus
//
//  Created by Eugene on 9/6/12.
//
//

#import "GWSerializable.h"

@interface OFSimpleIdentifier : GWSerializable

@property (nonatomic, retain) NSString *identifier;

@end
