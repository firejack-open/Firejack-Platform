//
//  GWDatePropertyView.h
//  Prometheus
//
//  Created by mjr on 6/26/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWFieldPropertyView.h"

@interface GWDatePropertyView : GWFieldPropertyView {
    UIDatePicker *_datePickerView;
}

@end
