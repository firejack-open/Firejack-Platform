//
//  GWObjectPropertyView.h
//  Prometheus
//
//  Created by mjr on 6/26/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWReferencePropertyView.h"

@interface GWObjectPropertyView : GWReferencePropertyView

@end
