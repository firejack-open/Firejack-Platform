//
//  GWMatchConstraint.m
//  Prometheus
//
//  Created by mjr on 7/4/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWMatchConstraint.h"

@implementation GWMatchConstraint

- (id)initWithConstraint:(GWRuleParameter *) constraint {
    self = [super initWithConstraint:constraint];
    if (self) {
        _match = [constraint.name isEqualToString:@"Match"];
        if (constraint.parameters) {
            for (GWKeyValue *entry in constraint.parameters) {
                if ([entry.key isEqualToString:@"expression"]) {
                    _regex = [[NSRegularExpression alloc] initWithPattern:(NSString *)entry.value options:NSRegularExpressionCaseInsensitive error:nil];
                }
            }
        }
    }
    return self;
}	

- (id)initWithCoder:(NSCoder *) decoder {
    if (self = [super initWithCoder:decoder]) {
        _regex = [[decoder decodeObjectForKey:@"regex"] retain];
        _match = [decoder decodeBoolForKey:@"match"];
    }
    return self;
}

- (void) encodeWithCoder:(NSCoder *) coder {
    [super encodeWithCoder:coder];
    
    [coder encodeObject:_regex forKey:@"regex"];
    [coder encodeBool:_match forKey:@"match"];
}

- (BOOL) validateValue:(id) value error:(NSString **) message  {
    NSString *text = (NSString *) value;
    NSArray *matches = [_regex matchesInString:text options:NSMatchingReportProgress range:NSMakeRange(0, text.length)];
    if ((_match && [matches count] == 0) || (!_match && [matches count] != 0)) {
        *message = self.error;
    }
    return *message == nil;
}

- (void)dealloc {
    [_regex release];
    [super dealloc];
}


@end
