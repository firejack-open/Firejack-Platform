//
//  OFAuthentication.h
//  Prometheus
//
//  Created by Eugene Maystrenko on 6/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "GWSerializable.h"
#import "OFUser.h"

@interface OFAuthentication : GWSerializable

@property (nonatomic, retain) NSString *token;
@property (nonatomic, retain) OFUser *user;

@end
