//
//  GWTreePropertyView.m
//  Prometheus
//
//  Created by mjr on 7/10/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWTreePropertyView.h"

@implementation GWTreePropertyView

- (id) initWithFrame:(CGRect) frame property:(GWProperty *) property {
    self = [super initWithFrame:RectSetHeight(frame, 75) property:property];
    if (self) {
        _canvas.frame = CGRectMake(0, 25, 450, 50);
        
        _child = [[UIButton alloc] initWithFrame:CGRectMake(460, 25, 165, 50)];
        _child.backgroundColor = [UIColor whiteColor];
        _child.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue" size:20];
        _child.layer.cornerRadius = 5;
        _child.layer.shadowColor = UIColorFromHex(0xE6EEF2).CGColor;
        _child.layer.shadowOffset = CGSizeMake(0, 1);
        _child.layer.borderColor = UIColorFromHex(0xC2C8CC).CGColor;
        _child.layer.borderWidth = 1;
        [_child setTitleColor:UIColorFromHex(0x98A7B2) forState:UIControlStateNormal];
        [_child setTitleColor:UIColorFromHex(0x6C7780) forState:UIControlStateHighlighted];
        [_child setTitle:[NSString stringWithFormat:@"add %@", [[(GWRelationship *)_property reference] name]] forState:UIControlStateNormal];
        [_child addTarget:self action:@selector(move:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_child];
        [_child release];
    }
    return self;
}

- (void) move:(id) sender {
    if ([self.delegate respondsToSelector:@selector(pushController:property:)]) {
        [self.delegate pushController:self property:_property];
    }
}

@end
