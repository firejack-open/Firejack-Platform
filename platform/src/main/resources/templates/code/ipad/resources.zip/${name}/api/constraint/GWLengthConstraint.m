//
//  GWLengthConstraint.m
//  Prometheus
//
//  Created by mjr on 7/3/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWLengthConstraint.h"

@implementation GWLengthConstraint


- (id)initWithConstraint:(GWRuleParameter *) constraint {
    self = [super initWithConstraint:constraint];
    if (self) {
        if (constraint.parameters) {
            for (GWKeyValue *entry in constraint.parameters) {
                if ([entry.key isEqualToString:@"min"]) {
                    _min = [(NSNumber *) entry.value integerValue];
                } else if ([entry.key isEqualToString:@"max"]) {
                    _max = [(NSNumber *) entry.value integerValue];
                } else if ([entry.key isEqualToString:@"minMsg"]) {
                    _minError = [(NSString *) entry.value retain];
                } else if ([entry.key isEqualToString:@"maxMsg"]) {
                    _maxError = [(NSString *) entry.value retain];
                }
            }
        }
    }
    return self;
}

- (id)initWithCoder:(NSCoder *) decoder {
    if (self = [super initWithCoder:decoder]) {
        _min = [decoder decodeIntegerForKey:@"min"];
        _max = [decoder decodeIntegerForKey:@"max"];
        _minError = [[decoder decodeObjectForKey:@"minError"] retain];
        _maxError = [[decoder decodeObjectForKey:@"maxError"] retain];
    }
    return self;
}

- (void) encodeWithCoder:(NSCoder *) coder {
    [super encodeWithCoder:coder];
    
    [coder encodeInteger:_min forKey:@"min"];
    [coder encodeInteger:_max forKey:@"max"];
    [coder encodeObject:_minError forKey:@"minError"];
    [coder encodeObject:_maxError forKey:@"maxError"];
}

- (BOOL) validateValue:(id) value error:(NSString **) message {
    if (!value) return YES;
    
    if ([value length] < _min)
        *message = _minError;
    else if ([value length] > _max)
        *message = _maxError;
    
    return *message == nil;
}

- (void)dealloc {
    [_minError release];
    [_maxError release];
    [super dealloc];
}


@end
