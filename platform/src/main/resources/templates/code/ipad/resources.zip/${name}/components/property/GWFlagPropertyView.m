//
//  GWFlagPropertyView.m
//  Prometheus
//
//  Created by mjr on 7/1/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWFlagPropertyView.h"

@implementation GWFlagPropertyView

- (id) initWithFrame:(CGRect) frame property:(GWProperty *) property {
    self = [super initWithFrame:RectSetHeight(frame, 75) property:property];
    if (self) {
        _checkbox = [[UIButton alloc] initWithFrame:CGRectMake(0, 25, 50, 50)];
        [_checkbox setBackgroundImage:[UIImage imageNamed:@"f_checkbox_f"] forState:UIControlStateNormal];
        [_checkbox setBackgroundImage:[UIImage imageNamed:@"f_checkbox_a"] forState:UIControlStateSelected];
        [_checkbox addTarget:self action:@selector(press:) forControlEvents:UIControlEventTouchUpInside];
        _checkbox.backgroundColor = [UIColor clearColor];
        [self addSubview:_checkbox];
        [_checkbox release];
    }
    return self;
}

- (void) prepare {
    [super prepare];
    _checkbox.selected = [[_property value:self.entity] boolValue];
}

- (void) press:(UIButton *) sender {
    sender.selected = !sender.selected;
    [_property setValue:[NSNumber numberWithBool:sender.selected] forObject:self.entity];
}

@end
