//
//  GWPhoneNumberPropertyView.h
//  Prometheus
//
//  Created by mjr on 7/1/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWFieldPropertyView.h"

@interface GWPhoneNumberPropertyView : GWFieldPropertyView {
    NSRegularExpression *_regex;
}

@end
