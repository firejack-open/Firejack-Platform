//
//  Error.m
//  Prometheus
//
//  Created by Eugene Maystrenko on 8/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "GWServerError.h"

@implementation GWServerError

- (id) initWithDictionary:(NSDictionary *) dictionary {
    if (self = [super initWithDictionary:dictionary]) {
		self.name = [Util get:dictionary key:@"name"];
        self.msg = [Util get:dictionary key:@"msg"];
	}
	return self;
}

- (void) dealloc {
    [_name release];
    [_msg release];
    [super dealloc];
}

@end
