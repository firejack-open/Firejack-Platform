//
//  GWReferenceView.h
//  Prometheus
//
//  Created by mjr on 7/22/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GWReferenceView : UIControl {
    UILabel *_headingLabel;
    UILabel *_subHeadingLabel;
    UILabel *_descriptionLabel;
}

@property (nonatomic, retain) NSString *heading;
@property (nonatomic, retain) NSString *subHeading;
@property (nonatomic, retain) NSString *description;

@property (nonatomic) CGFloat maxWidth;

- (void) layout;

@end
