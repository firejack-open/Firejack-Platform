//
//  GWAlertView.m
//  Prometheus
//
//  Created by mjr on 7/5/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWAlertView.h"

@implementation GWAlertView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.layer.cornerRadius = 5;
        self.backgroundColor = [UIColor whiteColor];
        
        _label = [[UILabel alloc] initWithFrame:CGRectZero];
        _label.backgroundColor = [UIColor clearColor];
        _label.textColor = UIColorFromHex(0x6C7880);
        _label.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:15];
        [self addSubview:_label];
        [_label release];
        
        _triangle = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"f_triangle"]];
        _triangle.hidden = YES;
        [self addSubview:_triangle];
        [_triangle release];
    }
    return self;
}

- (void) show:(NSString *) text inView:(UIView *) view {
    if (text) {
        CGSize size = [text sizeWithFont:_label.font];
        CGPoint center = view.center;
        
        _triangle.center = CGPointMake(size.width - 25, size.height + 15);
        self.frame = CGRectMake(center.x - size.width + 25, center.y - size.height - 35, size.width + 30, size.height + 10);
        _label.frame = CGRectMake(15, 5, size.width, size.height);
        _label.text = text;
    }

    [UIView beginAnimations:nil context:UIGraphicsGetCurrentContext];
    if (_visible) {
        self.alpha = 0;
        [UIView setAnimationTransition:UIViewAnimationTransitionCurlUp forView:self cache:YES];
    } else {
        [UIView setAnimationTransition:UIViewAnimationTransitionCurlDown forView:self cache:YES];
        self.alpha = 1;
    }
    
    [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
    [UIView setAnimationDuration:0.5];
    [UIView commitAnimations];

    _triangle.hidden = !_triangle.hidden;
    _visible = !_visible;
}

- (void) hide {
    if (_visible) {
        [UIView beginAnimations:nil context:UIGraphicsGetCurrentContext];
        self.alpha = 0;
        [UIView setAnimationTransition:UIViewAnimationTransitionCurlUp forView:self cache:YES];
        [UIView setAnimationCurve:UIViewAnimationCurveEaseInOut];
        [UIView setAnimationDuration:1];
        [UIView commitAnimations];
        
        _triangle.hidden = YES;
        _visible = NO;
    }
}

@end
