//
//  GWEnum.m
//  Prometheus
//
//  Created by mjr on 6/3/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWEnum.h"

@implementation GWEnum

- (id) initWithDictionary:(NSDictionary *) dictionary {
    if (self = [super initWithDictionary:dictionary]) {
		self.name = [Util get:dictionary key:@"name"];
        self.display = [Util get:dictionary key:@"display"];
        self.description = [Util get:dictionary key:@"description"];
	}
	return self;
}

- (NSMutableDictionary *) dictionary {
    NSMutableDictionary *dic = [super dictionary];
    [Util add:dic value:_name key:@"name"];
    [Util add:dic value:_display key:@"display"];
    [Util add:dic value:_description key:@"description"];
    return dic;
}

- (id)initWithCoder:(NSCoder *) decoder {
    if (self = [super init]) {
        self.name = [decoder decodeObjectForKey:@"name"];
        self.display = [decoder decodeObjectForKey:@"display"];
        self.description = [decoder decodeObjectForKey:@"description"];
    }
    return self;
}

- (void) encodeWithCoder:(NSCoder *) coder {
    [coder encodeObject:_name forKey:@"name"];
    [coder encodeObject:_display forKey:@"display"];
    [coder encodeObject:_description forKey:@"description"];
}

- (BOOL)isEqual:(id)other {
    if (other == self)
        return YES;
    if (!other || ![[other class] isEqual:[self class]])
        return NO;

    return [self isEqualToAnEnum:other];
}

- (BOOL)isEqualToAnEnum:(GWEnum *)anEnum {
    if (self == anEnum)
        return YES;
    if (anEnum == nil)
        return NO;
    if (self.name != anEnum.name && ![self.name isEqualToString:anEnum.name])
        return NO;
    return YES;
}

- (void) dealloc {
    [_name release];
    [_display release];
    [_description release];
    [super dealloc];
}

@end
