//
//  GWDatePropertyView.m
//  Prometheus
//
//  Created by mjr on 6/26/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWDatePropertyView.h"

@implementation GWDatePropertyView

- (id) initWithFrame:(CGRect) frame property:(GWProperty *) property {
    self = [super initWithFrame:frame property:property];
    if (self) {
        _datePickerView = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 704, 1024, 216)];
        [_datePickerView addTarget:self action:@selector(changeDate:) forControlEvents:UIControlEventValueChanged];
        
        if ([Util isIOS7]) {
            _datePickerView.backgroundColor = [UIColor whiteColor];
        }
        
        if (property.type == GWPropertyTypeDate)
            _datePickerView.datePickerMode = UIDatePickerModeDate;
        else if (property.type == GWPropertyTypeTime)
            _datePickerView.datePickerMode = UIDatePickerModeTime;
        else if (property.type == GWPropertyTypeFullTime)
            _datePickerView.datePickerMode = UIDatePickerModeDateAndTime;
    }
    return self;
}


- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    [self.mainView endEditing:YES];
    self.selected = !self.selected;
    return NO;
}

- (void) setSelected:(BOOL) selected {
    [super setSelected:selected];
    
    if (selected) {
        [self.mainView addSubview:_datePickerView];
        
        NSDate *date = [_property value:self.entity];
        if (date) {
            _datePickerView.date = date;
        }
    }
    
    [self show:selected];
}

- (void) show:(BOOL) show {
    [UIView animateWithDuration:0.4 delay:0 options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
                         if (show) {
                             _datePickerView.frame = CGRectOffset(_datePickerView.frame, 0, -ViewHeight(_datePickerView));
                         } else {
                             _datePickerView.frame = CGRectOffset(_datePickerView.frame, 0,  ViewHeight(_datePickerView));
                         }
                     } completion:^(BOOL finished){
                         if (!show) {
                             [_datePickerView removeFromSuperview];
                         }
                     }];
}

- (void) prepare {
    [super prepare];
    _textFieldView.text = [_property stringValue:self.entity];
}

- (void) changeDate:(UIDatePicker *) sender {
    [self setValue:sender.date];
    _textFieldView.text = [_property stringValue:self.entity];
}

- (void)dealloc {
    [_datePickerView release];
    [super dealloc];
}
@end
