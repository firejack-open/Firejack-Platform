//
//  OFImageFile.h
//  Prometheus
//
//  Created by Eugene Maystrenko on 7/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GWSerializable.h"

@interface OFImageFile : GWSerializable

@property (nonatomic, retain) NSString *filename;
@property (nonatomic, retain) NSString *orgFilename;
@property (nonatomic, retain) NSString *height;
@property (nonatomic, retain) NSString *width;
@property (nonatomic, retain) NSString *updated;

@end
