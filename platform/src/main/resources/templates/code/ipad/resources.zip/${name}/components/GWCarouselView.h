//
//  GWCarouselView.h
//  Prometheus
//
//  Created by Администратор on 2/28/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol GWCarouselDataSource, GWCarouselDelegate;

@interface GWCarouselView : UIScrollView<UIScrollViewDelegate> {
    UIView *select;
    CGFloat height;
    CGFloat center;
}

@property (nonatomic, assign) id <GWCarouselDataSource> dataSource;
@property (nonatomic, assign) id <GWCarouselDelegate> carouselDelegate;

- (void) reload;

@end

@protocol GWCarouselDataSource <NSObject>
- (NSUInteger) numberOfItemsInCarousel:(GWCarouselView *) carousel;
- (void) carousel:(GWCarouselView *) carousel index:(NSUInteger) index view:(UIView *) view;
@end

@protocol GWCarouselDelegate <NSObject>
- (void) carousel:(GWCarouselView *) carousel didSelectAtIndex:(NSUInteger) index;
@end