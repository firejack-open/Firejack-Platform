//
//  GWPropertyView.h
//  Prometheus
//
//  Created by mjr on 6/25/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GWAlertView.h"
#import "GWSlideView.h"
#import "GWRelationship.h"
#import "GWModel.h"
#import "GWProperty.h"
#import "GWConstraint.h"
#import "GWEntity.h"

@interface GWPropertyView : UIControl {
    UILabel *_labelView;
    GWProperty *_property;
    UIButton *_info;
    GWAlertView *_popup;
}

@property (nonatomic, retain) NSString *label;
@property (nonatomic, retain) GWEntity *entity;
@property (nonatomic, retain) UIView *mainView;
@property (nonatomic, retain) GWSlideView *sliderView;
@property (nonatomic, readonly) NSString *error;
@property (nonatomic, assign) id delegate;

- (id) initWithFrame:(CGRect) frame property:(GWProperty *) property;

- (BOOL) valid;
- (void) prepare;
- (void) prePersist;

- (GWPropertyType) propertyType;
- (SEL) referenceSelectorByType:(GWActionType) type;
- (NSString *) referencePath;

- (id) value;
- (void) setValue:(id) value;
- (void) removeObject:(id) value;

- (id) referenceHeading:(id) value;
- (id) referenceSubHeading:(id) value;
- (id) referenceDescription:(id) value;

@end

@protocol GWPropertyViewDelegate <NSObject>
@optional
- (void) layout:(GWPropertyView *) propertyView;
- (void) prepersist:(GWPropertyView *) propertyView property:(GWProperty *) property userObject:(id) userObject;
- (void) pushController:(GWPropertyView *) propertyView property:(GWProperty *) property;

@end