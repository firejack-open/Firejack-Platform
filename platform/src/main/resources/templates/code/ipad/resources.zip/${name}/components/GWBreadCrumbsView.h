//
//  GWBreadCrumbsView.h
//  Prometheus
//
//  Created by Администратор on 3/6/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GWMenuItem.h"
#import "UIImage+Utils.h"

@protocol GWBreadCrumbDelegate;

@interface GWBreadCrumbsView : UIView {
    UIImageView *_select;
    NSMutableArray *_index;
}

@property (nonatomic, retain) GWMenuItem *tree;
@property (nonatomic, retain) GWMenuItem *current;
@property (nonatomic, assign) id<GWBreadCrumbDelegate> delegate;

- (void) reload;

@end

@protocol GWBreadCrumbDelegate <NSObject>

- (void) breadCrumb:(GWBreadCrumbsView *) breadCrumbsView didSelect:(GWMenuItem *) item;
@end