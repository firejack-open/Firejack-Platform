//
//  GWPopoverGridView.m
//  Prometheus
//
//  Created by Eugene on 5/30/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWPopoverGridView.h"

@implementation GWPopoverGridView

- (id)initWithSize:(CGSize) size {
    self = [super init];
    if (self) {
        self.contentSizeForViewInPopover = size;
        _popover = [[UIPopoverController alloc] initWithContentViewController:self];
        self.tableView.rowHeight = 75;
        self.tableView.allowsSelection = NO;
    }
    return self;
}
- (void)dealloc {
    [_popover release];
    [_data release];
    [_model release];
    [super dealloc];
}

- (void) refreshForView:(UIView *)view {
    [self.tableView reloadData];
    [_popover presentPopoverFromRect:CGRectMake(30, 30, 1, 1) inView:view permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
}

#pragma mark Table view data source

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_data count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"Cell";
    GWSlideCellView *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell) {
        cell = [[[GWSlideCellView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
        cell.hideIcon = YES;
    }
    
    GWEntity *entity = _data[indexPath.row];
    
    cell.headingLabel.text = [_model headingValue:entity];
    cell.subHeadingLabel.text = [_model subHeadingValue:entity];
    cell.descriptionLabel.text = [_model descriptionValue:entity];
    
    return cell;
}

@end
