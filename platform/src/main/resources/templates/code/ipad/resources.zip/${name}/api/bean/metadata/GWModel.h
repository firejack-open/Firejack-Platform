//
//  GWModel.h
//  Prometheus
//
//  Created by Администратор on 3/29/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWSerializable.h"
#import "GWProperty.h"

@class GWRelationship;

typedef NS_ENUM(NSInteger, GWActionType) {
    GWActionTypeReadAll,
    GWActionTypeRead,
    GWActionTypeSearch,
    GWActionTypeAdvancedSearch,
    GWActionTypeCreate,
    GWActionTypeUpdate,
    GWActionTypeDelete,
    GWActionTypeSize    //enum size
};

@interface GWModel : GWSerializable <NSCoding> {
    SEL _selector[GWActionTypeSize];
}

@property (nonatomic, retain) NSString *lookup;
@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSString *controller;
@property (nonatomic, retain) NSString *heading;
@property (nonatomic, retain) NSString *subHeading;
@property (nonatomic, retain) NSString *description;
@property (nonatomic, retain) GWRelationship *parent;
@property (nonatomic, retain) NSArray *property;
@property (nonatomic, retain) NSArray *actions;

- (SEL) findSelectorByType:(GWActionType) type;

- (NSString *) headingValue:(id) value;
- (NSString *) subHeadingValue:(id) value;
- (NSString *) descriptionValue:(id) value;

@end
