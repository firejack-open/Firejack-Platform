//
//  GWPropertyRule.m
//  Prometheus
//
//  Created by mjr on 7/2/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWPropertyRule.h"

@implementation GWPropertyRule

- (id) initWithDictionary:(NSDictionary *) dictionary {
    if (self = [super initWithDictionary:dictionary]) {
		self.name = [Util get:dictionary key:@"name"];
        self.defaultValue = [Util get:dictionary key:@"defaultValue"];
        self.rules = [Util getList:dictionary key:@"constraints" bean:[GWRuleParameter class]];
	}
	return self;
}

- (void)dealloc {
    [_name release];
    [_defaultValue release];
    [_rules release];
    [super dealloc];
}
@end
