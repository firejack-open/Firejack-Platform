//
//  GWSlideCellView.m
//  Prometheus
//
//  Created by Eugene on 7/23/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWSlideCellView.h"

@implementation GWSlideCellView

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        
        _headingLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 10, 270, 24)];
        _headingLabel.font = [UIFont fontWithName:@"HelveticaNeue" size:18];
        _headingLabel.textColor = [UIColor blackColor];
        _headingLabel.shadowColor = UIColorFromHex(0xE6EEF2);
        _headingLabel.shadowOffset = CGSizeMake(0, 1);
        _headingLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:_headingLabel];
        [_headingLabel release];
        
        _subHeadingLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 30, 270, 19)];
        _subHeadingLabel.font = [UIFont fontWithName:@"HelveticaNeue" size:14];
        _subHeadingLabel.textColor = UIColorFromHex(0x0068B2);
        _subHeadingLabel.shadowColor = UIColorFromHex(0xE6EEF2);
        _subHeadingLabel.shadowOffset = CGSizeMake(0, 1);
        _subHeadingLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:_subHeadingLabel];
        [_subHeadingLabel release];
        
        _descriptionLabel = [[UILabel alloc] initWithFrame:CGRectMake(15, 46, 270, 19)];
        _descriptionLabel.font = [UIFont fontWithName:@"HelveticaNeue" size:14];
        _descriptionLabel.textColor = UIColorFromHex(0xA3BBCC);
        _descriptionLabel.shadowColor = UIColorFromHex(0xE6EEF2);
        _descriptionLabel.shadowOffset = CGSizeMake(0, 1);
        _descriptionLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:_descriptionLabel];
        [_descriptionLabel release];
        
        _iconView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"s_checkmark_f"] highlightedImage:[UIImage imageNamed:@"s_checkmark_a"]];
        _iconView.frame = CGRectMake(286, 29.5, 16, 16);
        [self addSubview:_iconView];
        [_iconView release];
    
        UIView *selected = [[UIView alloc] initWithFrame:CGRectZero];
        selected.backgroundColor = UIColorFromHex(0x73B6E5);
        self.selectedBackgroundView = selected;
        [selected release];
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];
    if (selected) {
        _headingLabel.textColor = [UIColor whiteColor];
        _subHeadingLabel.textColor = [UIColor whiteColor];
        _descriptionLabel.textColor = UIColorFromHex(0xB2DFFF);
    } else {
        _headingLabel.textColor = [UIColor blackColor];
        _subHeadingLabel.textColor = UIColorFromHex(0x0068B2);
        _descriptionLabel.textColor = UIColorFromHex(0xA3BBCC);
    }
    _iconView.highlighted = selected;
    _iconView.hidden = _hideIcon;
}

- (void) dealloc {
    [_headingLabel release];
    [_subHeadingLabel release];
    [_descriptionLabel release];
    [super dealloc];
}

@end
