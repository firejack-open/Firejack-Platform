//
//  GWBaseViewController.m
//  Prometheus
//
//  Created by Eugene Maystrenko on 6/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "GWBaseViewController.h"

@interface GWBaseViewController ()

@end

@implementation GWBaseViewController

- (id) init {
    self.delegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    self.api = [API shared];
    return [super init];
}

- (void) viewWillAppear:(BOOL)animated {
    self.api.delegate = self;
    [super viewWillAppear:animated];
}

- (void)viewDidLoad {
    if (!self.delegate) self.delegate = (AppDelegate *) [[UIApplication sharedApplication] delegate];
    if (!self.api)self.api = [API shared];
    [super viewDidLoad];
	// Do any additional setup after loading the view.
}

- (void)viewDidUnload
{
    [super viewDidUnload];
    // Release any retained subviews of the main view.
}

- (IBAction) back:(id)sender  {
    [self.navigationController popViewControllerAnimated:YES];
}

- (void) error:(NSString *) message {
    if (message) {
        [message retain];
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:message
                                                       delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        [alert release];
    
    }
}

- (void)dealloc {
	[_delegate release];
    [_api release];
    [super dealloc];
}

@end
