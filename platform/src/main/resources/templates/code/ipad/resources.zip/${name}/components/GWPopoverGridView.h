//
//  GWPopoverGridView.h
//  Prometheus
//
//  Created by Eugene on 5/30/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GWModel.h"
#import "GWEntity.h"
#import "GWSlideCellView.h"

@interface GWPopoverGridView : UITableViewController  {
    UIPopoverController *_popover;
    NSArray *_data;
}

@property (nonatomic, retain) GWModel *model;
@property (nonatomic, retain) NSArray *data;

- (id) initWithSize:(CGSize) size;

- (void) refreshForView:(UIView *) view;

@end
