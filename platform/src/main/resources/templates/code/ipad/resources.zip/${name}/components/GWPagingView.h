//
//  GWPagingView.h
//  Prometheus
//
//  Created by Администратор on 4/1/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIImage+Utils.h"
#import "GWTextFieldView.h"

@protocol GWPagingDelegate;

@interface GWPagingView : UIView<UITextFieldDelegate> {
    UIButton *_first;
    UIButton *_prev;
    GWTextFieldView *_current;
    UILabel *_of;
    UIButton *_next;
    UIButton *_last;
    int _page;
}

@property (nonatomic) int offset;
@property (nonatomic, retain) NSNumber *total;
@property (nonatomic, retain) NSNumber *limit;

@property (nonatomic, assign) id<GWPagingDelegate> delegate;

- (void) reload;

@end

@protocol GWPagingDelegate <NSObject>

- (void) paging:(GWPagingView *)paging offset:(NSNumber *)offset limit:(NSNumber *) limit;

@end