//
//  GWEntityPickerView.h
//  Prometheus
//
//  Created by Администратор on 4/11/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GWPagingView.h"

typedef NS_ENUM(NSInteger, GWEntityPickerType) {
    GWEntityPickerTypeSingleSelect,
    GWEntityPickerTypeMultiSelect,
    GWEntityPickerTypeTreeSelect
};

@protocol GWEntityPickerDataSource, GWEntityPickerDelegate;

@interface GWEntityPickerView : UIView<UIPickerViewDataSource, UIPickerViewDelegate, GWPagingDelegate>  {
    UIPickerView *_dataPickerView;
    GWPagingView *_pagingView;
    NSUInteger _count;

}

@property (nonatomic, assign) id<GWEntityPickerDataSource> dataSource;
@property (nonatomic, assign) id<GWEntityPickerDelegate> delegate;
@property (nonatomic) GWEntityPickerType type;
@property (nonatomic) BOOL visible;
- (void) reload;
- (void) showHideView;

@end

@protocol GWEntityPickerDataSource <NSObject>

- (void) picker:(GWEntityPickerView *) picker offset:(NSNumber *) offset limit:(NSNumber *) limit total:(NSNumber **) total;
- (NSString *) picker:(GWEntityPickerView *) picker titleForRow:(NSUInteger) row;
@optional
- (BOOL) picker:(GWEntityPickerView *) picker isSelectedRow:(NSUInteger) row;

@end

@protocol GWEntityPickerDelegate <NSObject>

- (void) picker:(GWEntityPickerView *) picker didSelectForRow:(NSUInteger) row;
@optional
- (void) picker:(GWEntityPickerView *) picker didDeselectForRow:(NSUInteger) row;
@end