//
//  GWRuleParameter.h
//  Prometheus
//
//  Created by mjr on 6/5/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWSerializable.h"
#import "GWKeyValue.h"

@interface GWRuleParameter : GWSerializable

@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSString *errorMessage;
@property (nonatomic, retain) NSArray *parameters;

@end
