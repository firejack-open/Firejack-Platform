//
//  GWMenuViewController.m
//  Prometheus
//
//  Created by Администратор on 2/28/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWMenuViewController.h"

static NSString *domain = @"Domain";
static NSString *report = @"Report";

@implementation GWMenuViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {

        UIImageView *background = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"l_background"]];
        [self.view addSubview:background];
        [background release];
        
        _breadCrumbs = [[GWBreadCrumbsView alloc] initWithFrame:CGRectMake(0, 0, 1024, 44)];
        _breadCrumbs.delegate = self;
        [self.view addSubview:_breadCrumbs];
        [_breadCrumbs release];
        
        _carouselView = [[GWCarouselView alloc] initWithFrame:CGRectMake(0, 200, 1024, 330)];
        _carouselView.dataSource = self;
        _carouselView.carouselDelegate = self;
        [self.view addSubview:_carouselView];
        [_carouselView release];
        
        UIImageView *devider = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"m_scroll_path"]];
        devider.frame = CGRectMake(192, 530, 640, 1);
        [self.view addSubview:devider];
        [devider release];
        
        UIButton *logout = [[UIButton alloc] initWithFrame:CGRectMake(470, 645, 70, 30)];
        logout.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:12];
        logout.titleLabel.textColor = [UIColor whiteColor];
        logout.titleLabel.layer.shadowColor = UIColorFromHex(0x1F2933).CGColor;
        logout.titleLabel.layer.shadowOffset = CGSizeMake(0, -1);
        [logout setTitle:@"Logout" forState:UIControlStateNormal];
        [logout addTarget:self action:@selector(logout:) forControlEvents:UIControlEventTouchUpInside];
        [logout setBackgroundImage:[UIImage stretchableImageNamed:@"gr_button_red_cf" left:@"gr_button_red_lf" rigth:@"gr_button_red_rf" toSize:logout.frame.size] forState:UIControlStateNormal];
        [logout setBackgroundImage:[UIImage stretchableImageNamed:@"gr_button_red_ca" left:@"gr_button_red_la" rigth:@"gr_button_red_ra" toSize:logout.frame.size] forState:UIControlStateSelected];
        [self.view addSubview:logout];
        [logout release];
        
        UILabel *footer = [[UILabel alloc] initWithFrame:CGRectMake(0, 700, 1024, 20)];
        footer.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:16];
        footer.textColor = UIColorFromHex(0x3D7399);
        footer.layer.shadowColor = UIColorFromHex(0xE5F4FF).CGColor;
        footer.layer.shadowOffset = CGSizeMake(0, 1);
        footer.backgroundColor = [UIColor clearColor];
        footer.text = @"Powered by Firejack";
        footer.textAlignment = NSTextAlignmentCenter;
        [self.view addSubview:footer];
        [footer release];
        
        [_items release];
        _items = [[self.api loadMenu] retain];
        self.current = _items;
        
        GWMenuItem *home = [[GWMenuItem alloc] init];
        home.title = @"Home";
        home.items = _items;
        for (GWMenuItem *item in _items) {
            item.parent = home;
        }
        
        _breadCrumbs.tree = home;
        [home release];
        
        [_breadCrumbs reload];
        [_carouselView reload];
        
        if ([Util isIOS7]) {
            for (UIView *view in self.view.subviews) {
                view.frame  = CGRectOffset(view.frame, 0, 20);
            }
        }
    }
    return self;
}

- (void) viewWillAppear:(BOOL)animated {
    self.navigationController.navigationBarHidden = YES;
    [super viewWillAppear:animated];
}

- (void) viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void) logout:(id) sender {
    [self.api logout];
    [self.delegate.modelManager persist];
    [self.navigationController popToRootViewControllerAnimated:YES];
}


#pragma  -
#pragma mark Bread Crumb Delegate

- (void) breadCrumb:(GWBreadCrumbsView *) breadCrumbsView didSelect:(GWMenuItem *) item {
    _current = item.items;
    [_carouselView reload];
}

#pragma  -
#pragma mark Carousel Data Source

- (NSUInteger) numberOfItemsInCarousel:(GWCarouselView *)carousel {
    return [_current count];
}

- (void) carousel:(GWCarouselView *)carousel index:(NSUInteger) index view:(UIView *) view {
    GWMenuItem *item = [_current objectAtIndex:index];
    UIImageView *imageView;
    
    UILabel *name = [[UILabel alloc] initWithFrame:CGRectMake(0, 30, 204.8, 30)];
    name.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:25];
    name.textColor = UIColorFromHex(0x4c6a80);
    name.backgroundColor = [UIColor clearColor];
    name.text = item.title;
    name.textAlignment = NSTextAlignmentCenter;
    [view addSubview:name];
    [name release];
 
    UILabel *type = [[UILabel alloc] initWithFrame:CGRectMake(0, 60, 204.8, 20)];
    type.font = [UIFont fontWithName:@"HelveticaNeue" size:15];
    type.textColor = UIColorFromHex(0x4c6a80);
    type.backgroundColor = [UIColor clearColor];
    type.textAlignment = NSTextAlignmentCenter;
    [view addSubview:type];
    [type release];

    if ([item.type isEqualToString:domain]) {
        imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"m_domain"]];
    } else if ([item.type isEqualToString:report]) {
        imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"m_report"]];
    } else {
        imageView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"m_table"]];
    }

    type.text = item.type;
    imageView.center = CGPointMake(102.4, 165);
    [view addSubview:imageView];
    [imageView release];
}

- (void) carousel:(GWCarouselView *) carousel didSelectAtIndex:(NSUInteger) index {
    GWMenuItem *menu = [_current objectAtIndex:index];
    if (menu.items) {
        _breadCrumbs.current = menu;
        _current = menu.items;
        [_breadCrumbs reload];
        [carousel reload];
    } else if (menu.entity) {
        GWModel *metadata = [self.delegate.modelManager model:menu.entity];
        
        UIViewController *controller = [[NSClassFromString(metadata.controller) alloc] initWithModel:metadata];
        [self.navigationController pushViewController:controller animated:YES];
        [controller release];
    }
}

- (void) dealloc {
    [_current release];
    [_items release];
    [super dealloc];
}

@end
