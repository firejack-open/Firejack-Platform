//
//  GWPopupView.h
//  Prometheus
//
//  Created by Администратор on 3/6/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GWMenuItem.h"

@protocol GWPopupViewDelegate;

@interface GWPopupView : UIView<UITableViewDelegate, UITableViewDataSource> {
    UITableView *_tableView;
    UIImageView *_arrow;
}

@property (nonatomic, retain) NSArray *list;
@property (nonatomic, assign) id<GWPopupViewDelegate> delegate;

- (void) show:(CGRect) frame;

@end;

@protocol GWPopupViewDelegate <NSObject>

- (void) popup:(GWPopupView *) popup didSelect:(GWMenuItem *) item;

@end
