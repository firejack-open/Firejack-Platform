//
//  OFImageResourceVersion.h
//  Prometheus
//
//  Created by Eugene Maystrenko on 7/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "GWEntity.h"

@interface OFImageResourceVersion : GWEntity

@property (nonatomic, retain) NSString *title;
@property (nonatomic, retain) NSString *culture;
@property (nonatomic, retain) NSString *width;
@property (nonatomic, retain) NSString *height;
@property (nonatomic, retain) NSString *resourceFileOriginalName;
@property (nonatomic, retain) NSString *resourceFileTemporaryName;
@property (nonatomic, retain) NSString *resourceLookup;
@property (nonatomic, retain) NSString *version;

@end
