//
//  GWRuleParameter.m
//  Prometheus
//
//  Created by mjr on 6/5/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWRuleParameter.h"

@implementation GWRuleParameter

- (id) initWithDictionary:(NSDictionary *) dictionary {
    if (self = [super initWithDictionary:dictionary]) {
		self.name = [Util get:dictionary key:@"name"];
        self.errorMessage = [Util get:dictionary key:@"errorMessage"];
        self.parameters = [Util getList:dictionary key:@"params" bean:[GWKeyValue class]];
	}
	return self;
}

- (void)dealloc {
    [_name release];
    [_errorMessage release];
    [_parameters release];
    [super dealloc];
}
@end
