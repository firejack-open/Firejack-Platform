//
//  GWAlertView.h
//  Prometheus
//
//  Created by mjr on 7/5/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GWAlertView : UIView {
    UILabel *_label;
    UIImageView *_triangle;
}

@property (nonatomic) BOOL visible;

- (void) show:(NSString *) text inView:(UIView *) view;
- (void) hide;

@end
