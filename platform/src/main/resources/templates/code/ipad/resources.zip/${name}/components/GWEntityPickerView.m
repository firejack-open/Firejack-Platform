//
//  GWEntityPickerView.m
//  Prometheus
//
//  Created by Администратор on 4/11/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWEntityPickerView.h"

@implementation GWEntityPickerView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        if ([Util isIOS7]) {
            self.backgroundColor = [UIColor whiteColor];
        } else {
            UIImageView *background = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"ep_background"]];
            [self addSubview:background];
            [background release];
        }
        
        _dataPickerView = [[UIPickerView alloc] initWithFrame:CGRectMake(0, 0, RectWidth(frame), 216)];
        _dataPickerView.dataSource = self;
        _dataPickerView.delegate = self;
        [self addSubview:_dataPickerView];
        [_dataPickerView release];
        
        _pagingView = [[GWPagingView alloc] initWithFrame:CGRectMake(0, 216, RectWidth(frame), 46)];
        _pagingView.limit = @10;
        _pagingView.delegate = self;
        [self addSubview:_pagingView];
        [_pagingView release];
    }
    return self;
}

- (void)dealloc {
    [super dealloc];
}

- (void) showHideView {
    [UIView beginAnimations:@"showHideView" context:NULL];
	if (_visible) {
		self.frame = CGRectOffset(self.frame, 0, ViewHeight(self));
	} else {
        self.frame = CGRectOffset(self.frame, 0, -ViewHeight(self));
	}
    [UIView commitAnimations];
    _visible = !_visible;
}

- (void) reload {
    _dataPickerView.showsSelectionIndicator = _type != GWEntityPickerTypeMultiSelect;
    [_pagingView reload];
}

#pragma mark -
#pragma mark Picker Data Source

- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView {
    return 1;
}

- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component {
    return _count == 0 ? 1 : _count;
}

- (UIView *)pickerView:(UIPickerView *)pickerView viewForRow:(NSInteger)row forComponent:(NSInteger)component reusingView:(UIView *)view {
    if (_count == 0) return nil;
    UITableViewCell *cell = (UITableViewCell *)view;
    
    if (cell == nil) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:nil] autorelease];
        [cell setBackgroundColor:[UIColor clearColor]];
        
        if (_type == GWEntityPickerTypeMultiSelect) {
            UITapGestureRecognizer *tapGestureRecognizer = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(selection:)];
            [cell addGestureRecognizer:tapGestureRecognizer];
            [tapGestureRecognizer release];
        }
    }
    
    cell.textLabel.text = [_dataSource picker:self titleForRow:row];
    cell.accessoryType = UITableViewCellAccessoryNone;
    cell.tag = row;
    
    if (_type == GWEntityPickerTypeMultiSelect && [_dataSource respondsToSelector:@selector(picker:isSelectedRow:)]) {
        BOOL selected = [_dataSource picker:self isSelectedRow:row];
        if (selected) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }
    }

    return cell;
}

- (void) selection:(UITapGestureRecognizer *)recognizer {
    UITableViewCell *cell = (UITableViewCell *) recognizer.view;

    if (cell.accessoryType == UITableViewCellAccessoryCheckmark) {
        cell.accessoryType = UITableViewCellAccessoryNone;
        [_delegate picker:self didDeselectForRow:cell.tag];
    } else {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
        [_delegate picker:self didSelectForRow:cell.tag];
    }
}

#pragma mark -
#pragma mark Picker Delegate

- (void)pickerView:(UIPickerView *)pickerView didSelectRow:(NSInteger)row inComponent:(NSInteger)component {
    if (_count != 0 && _type != GWEntityPickerTypeMultiSelect) [_delegate picker:self didSelectForRow:row];
}

#pragma mark -
#pragma mark Paging Delegate

- (void)paging:(GWPagingView *)paging offset:(NSNumber *)offset limit:(NSNumber *) limit {
    NSNumber *total = nil;
    [_dataSource picker:self offset:offset limit:limit total:&total];
    _pagingView.total = total;
    
    if ([offset intValue] + [limit intValue] < [total intValue]) {
        _count = [limit intValue];
    } else {
        _count = [total intValue] - [offset intValue];
    }
    
    [_dataPickerView reloadAllComponents];
    
   // NSUInteger row = [_dataPickerView selectedRowInComponent:0];
    //[_delegate picker:self didSelectForRow:row];
}

@end
