//
//  GWMenuViewController.h
//  Prometheus
//
//  Created by Администратор on 2/28/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWBaseViewController.h"
#import "GWEntityViewController.h"
#import "GWCarouselView.h"
#import "GWBreadCrumbsView.h"
#import "UIImage+Utils.h"

@interface GWMenuViewController : GWBaseViewController <GWCarouselDataSource, GWCarouselDelegate, GWBreadCrumbDelegate> {
    GWBreadCrumbsView *_breadCrumbs;
    GWCarouselView *_carouselView;
    NSArray *_items;
}

@property (nonatomic, retain) NSArray *current;
@end
