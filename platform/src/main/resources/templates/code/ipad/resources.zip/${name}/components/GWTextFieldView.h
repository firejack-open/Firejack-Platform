//
//  GWTextFieldView.h
//  Prometheus
//
//  Created by Eugene Maystrenko on 8/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GWTextFieldView : UITextField

@property (nonatomic) CGFloat dx;
@property (nonatomic) CGFloat dy;
@property (nonatomic) CGRect leftIcon;
@property (nonatomic) CGRect rightIcon;

@end
