//
//  OFSimpleIdentifier.m
//  Prometheus
//
//  Created by Eugene on 9/6/12.
//
//

#import "OFSimpleIdentifier.h"

@implementation OFSimpleIdentifier

- (id) initWithDictionary:(NSDictionary *) dictionary {
    if (self = [super initWithDictionary:dictionary]) {
		self.identifier = [Util get:dictionary key:@"identifier"];
	}
	return self;
}

- (void) dealloc{
    [_identifier release];
    [super dealloc];
}


@end
