//
//  GWModel.m
//  Prometheus
//
//  Created by Администратор on 3/29/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWModel.h"

@class GWRelationship;

@implementation GWModel

- (id)initWithCoder:(NSCoder *) decoder {
    if (self = [super init]) {
        self.lookup = [decoder decodeObjectForKey:@"lookup"];
        self.name = [decoder decodeObjectForKey:@"name"];
        self.controller = [decoder decodeObjectForKey:@"controller"];
        self.heading = [decoder decodeObjectForKey:@"heading"];
        self.subHeading = [decoder decodeObjectForKey:@"subHeading"];
        self.description = [decoder decodeObjectForKey:@"description"];
        self.parent = [decoder decodeObjectForKey:@"parent"];
        self.property = [decoder decodeObjectForKey:@"property"];
        self.actions = [decoder decodeObjectForKey:@"actions"];
    }
    return self;
}

- (void) encodeWithCoder:(NSCoder *) coder {
    [coder encodeObject:_lookup forKey:@"lookup"];
    [coder encodeObject:_name forKey:@"name"];
    [coder encodeObject:_controller forKey:@"controller"];
    [coder encodeObject:_heading forKey:@"heading"];
    [coder encodeObject:_subHeading forKey:@"subHeading"];
    [coder encodeObject:_description forKey:@"description"];
    [coder encodeObject:_parent forKey:@"parent"];
    [coder encodeObject:_property forKey:@"property"];
    [coder encodeObject:_actions forKey:@"actions"];
}

- (SEL) findSelectorByType:(GWActionType) type {
    SEL selector = _selector[type];
    if (!selector && _actions) {
        for (GWActionType index = 0; index < GWActionTypeSize; index++) {
            _selector[index] = NSSelectorFromString([_actions objectAtIndex:index]);
        }
        
        selector = _selector[type];
    }
    return selector;
}

- (NSString *) headingValue:(id) value {
    return [Util replaceEntityPlaceholder:_heading block:^(NSString *key) {
        return [self stringProperty:key value:value];
    }];
}

- (NSString *) subHeadingValue:(id) value {
    return [Util replaceEntityPlaceholder:_subHeading block:^(NSString *key) {
        return [self stringProperty:key value:value];
    }];
}

- (NSString *) descriptionValue:(id) value {
    return [Util replaceEntityPlaceholder:_description block:^(NSString *key) {
        return [self stringProperty:key value:value];
    }];
}

- (NSString *) stringProperty:(NSString *) key value:(id) value {
    for (GWProperty *item in _property) {
        if ([item.name isEqualToString:key]) {
            return [item stringValue:value];
        }
    }
    return nil;
}

- (void)dealloc {
    [_lookup release];
    [_name release];
    [_controller release];
    [_heading release];
    [_subHeading release];
    [_description release];
    [_parent release];
    [_property release];
    [_actions release];
    [super dealloc];
}
@end
