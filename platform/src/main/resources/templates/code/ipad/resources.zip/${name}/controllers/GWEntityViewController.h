//
//  GWEntityViewController.h
//  Prometheus
//
//  Created by mjr on 7/15/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWBaseViewController.h"

@interface GWEntityViewController : GWBaseViewController {
    GWModel *_model;
}

@property (nonatomic, retain) GWEntity *parent;
@property (nonatomic, retain) GWProperty *parentProperty;
@property (nonatomic, retain) NSString *queryParameters;
@property (nonatomic, retain) NSString *sortOrder;

- (id)initWithModel:(GWModel *) model;

@end
