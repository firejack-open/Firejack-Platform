//
//  UIImage+Utils.h
//  Prometheus
//
//  Created by Администратор on 3/25/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIImage (Utils)

+ (UIImage *) cropImageNamed:(NSString *)name toRect:(CGRect) rect;
+ (UIImage *) cropImageNamed:(NSString *)name toSize:(CGSize) size;
+ (UIImage *) stretchableImageNamed:(NSString *) streatchable left:(NSString *) left rigth:(NSString *) right toSize:(CGSize) size;

- (UIImage *) joinHorizontal:(NSString *) name;

@end
