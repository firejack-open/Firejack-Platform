//
//  UIImage+Utils.m
//  Prometheus
//
//  Created by Администратор on 3/25/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "UIImage+Utils.h"

@implementation UIImage (Utils)

+ (UIImage *) cropImageNamed:(NSString *)name toRect:(CGRect) rect {
    rect.size.width *= 2;
    rect.size.height *= 2;
    UIImage *image = [UIImage imageNamed:name];
    CGImageRef imageRef = CGImageCreateWithImageInRect([image CGImage], rect);
    UIImage *cropped = [UIImage imageWithCGImage:imageRef];
    CGImageRelease(imageRef);
    return cropped;
}

+ (UIImage *) cropImageNamed:(NSString *)name toSize:(CGSize) size {
    return [self cropImageNamed:name toRect:CGRectMake(0, 0, size.width, size.height)];
}

+ (UIImage *) stretchableImageNamed:(NSString *) streatchable left:(NSString *) left rigth:(NSString *) right toSize:(CGSize) size {
    UIImage *imageLeft = [UIImage imageNamed:left];
    UIImage *imageRight = [UIImage imageNamed:right];
    
    CGFloat width = size.width;
    if (imageLeft) width -= imageLeft.size.width;
    if (imageRight) width -= imageLeft.size.width;
    
    UIImage *temp = [UIImage imageNamed:streatchable];
    CGImageRef imageRef = CGImageCreateWithImageInRect([temp CGImage], CGRectMake(0, 0, width * 2, size.height * 2));
    UIImage *imageCenter = [UIImage imageWithCGImage:imageRef];
    CGImageRelease(imageRef);
    
    size.width *= 2;
    size.height *= 2;
    
    UIGraphicsBeginImageContext(size);
    
    CGFloat x = 0;
    if (imageLeft) {
        [imageLeft drawInRect:CGRectMake(x, 0, imageLeft.size.width * 2, imageLeft.size.height * 2)];
        x += imageLeft.size.width * 2;
    }
    
    if (imageCenter) {
        [imageCenter drawInRect:CGRectMake(x, 0, imageCenter.size.width, imageCenter.size.height)];
        x += imageCenter.size.width;
    }

    if (imageRight) {
        [imageRight drawInRect:CGRectMake(x, 0, imageRight.size.width * 2, imageRight.size.height * 2)];
    }

    UIImage *image = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return image;
}

- (UIImage *) joinHorizontal:(NSString *) name {
    UIImage *image = [UIImage imageNamed:name];
    
    CGSize newSize = CGSizeMake(self.size.width + image.size.width * 2, self.size.height);
    UIGraphicsBeginImageContext(newSize);

    [self drawInRect:CGRectMake(0,0,self.size.width,self.size.height)];
    [image drawInRect:CGRectMake(self.size.width,0,image.size.width * 2,image.size.height * 2)];
    
    UIImage *newImage = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return newImage;
}

@end
