//
//  GWPopupView.m
//  Prometheus
//
//  Created by Администратор on 3/6/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWPopupView.h"

#define INDENT 5

@implementation GWPopupView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.alpha = 0;
        _arrow = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"l_login_a"]];
        _arrow.center = CGPointMake(frame.size.width/2, - 10);
        [self addSubview:_arrow];
        [_arrow release];
        
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(INDENT, INDENT, frame.size.width - INDENT*2, frame.size.height - INDENT*2)];
        _tableView.dataSource = self;
        _tableView.delegate = self;
        [self addSubview:_tableView];
        [_tableView release];
    }
    return self;
}

- (void) show:(CGRect) frame {
    _arrow.center = CGPointMake(frame.size.width/2, - 10);
	
    CGFloat left = frame.origin.x - frame.size.width/2;
    CGFloat right = frame.origin.x + frame.size.width/2;
    if (left < 0) {
        frame.origin.x = 0;
    } else if (right > 1024) {
        frame.origin.x = 1024 - frame.size.width;
    }
    
    self.frame = frame;
    _tableView.frame = CGRectMake(INDENT, INDENT, frame.size.width - INDENT*2, frame.size.height - INDENT*2);
    [_tableView reloadData];
    
    self.alpha = 1;
}

- (void) hide {
    self.alpha = 0;
}

#pragma mark Table Data Source

- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger)section {
    return self.list.count;
}

- (UITableViewCell *)tableView:(UITableView *) table cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [table dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell) {
        cell = [[[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
    NSInteger row = [indexPath row];
    GWMenuItem *item = [self.list objectAtIndex:row];
    cell.textLabel.text = item.title;
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [self hide];
    
    NSInteger row = [indexPath row];
    GWMenuItem *item = [self.list objectAtIndex:row];
    
    if ([_delegate respondsToSelector:@selector(popup:didSelect:)]) {
        [_delegate popup:self didSelect:item];
    }
}

- (void)dealloc {
    [_list release];
    [super dealloc];
}
@end
