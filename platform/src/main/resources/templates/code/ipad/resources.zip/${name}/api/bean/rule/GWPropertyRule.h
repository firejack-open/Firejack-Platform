//
//  GWPropertyRule.h
//  Prometheus
//
//  Created by mjr on 7/2/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWSerializable.h"
#import "GWRuleParameter.h"

@interface GWPropertyRule : GWSerializable

@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSObject *defaultValue;
@property (nonatomic, retain) NSArray *rules;

@end
