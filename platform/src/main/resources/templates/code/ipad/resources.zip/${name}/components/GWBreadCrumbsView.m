//
//  GWBreadCrumbsView.m
//  Prometheus
//
//  Created by Администратор on 3/6/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWBreadCrumbsView.h"

#define WIDTH 70
#define HEIGHT 44
#define PADDING 18

@implementation GWBreadCrumbsView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor blackColor];
        _index = [[NSMutableArray alloc] init];
        _select = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"bc_select_triangle"]];
    }
    return self;
}

- (void) reload {
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    if (!_current) {
        self.current = _tree;
    }
    [self construct:_current.parent child:_current];
    
    UIButton *last = _current.button;
    last.enabled = NO;
     [self addSubview:_select];
    _select.center = CGPointMake(last.center.x, last.center.y * 2 + 4.75);
}

- (void) construct:(GWMenuItem *) parent child:(GWMenuItem *) child {
    if (parent) {
        [self construct:parent.parent child:parent];
    }
    
    UIButton *node = [self createNextButton:child previus:parent];
    node.enabled = YES;
    [self addSubview:node];
    [self sendSubviewToBack:node];
}

- (UIButton *) createNextButton:(GWMenuItem *) item previus:(GWMenuItem *) previus {
    if (item.button) return item.button;
    
    CGFloat textWidth = [item.title sizeWithFont:[UIFont fontWithName:@"HelveticaNeue-Bold" size:15]].width;
    CGFloat width = textWidth + PADDING * 2;
    
    CGRect frame;
    if(previus){
        frame = previus.button.frame;
        frame.origin.x = frame.origin.x + frame.size.width - PADDING;
        frame.size.width = width;
    } else {
        frame = CGRectMake(0, 0, width, HEIGHT);
    }
    
    UIButton *node = [[UIButton alloc] initWithFrame:frame];
    [node setTitle:item.title forState:UIControlStateNormal];
    [node setBackgroundImage:[[UIImage cropImageNamed:@"bc_breadcrumbs_f" toSize:CGSizeMake(textWidth + PADDING, HEIGHT)] joinHorizontal:@"bc_triangle"] forState:UIControlStateNormal];
    [node setBackgroundImage:[UIImage cropImageNamed:@"bc_last_node" toSize:CGSizeMake(width, HEIGHT)] forState:UIControlStateDisabled];
    [node addTarget:self action:@selector(choise:) forControlEvents:UIControlEventTouchUpInside];
    node.layer.masksToBounds = YES;
    node.layer.cornerRadius = 4;
    node.titleLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:15];
    node.titleLabel.shadowColor = UIColorFromHex(144466);
    node.titleLabel.shadowOffset = CGSizeMake(0, -1);
    
    item.button = node;
    [node release];
    
    [_index addObject:item];
    return node;
}

- (void) choise:(UIButton *) sender {
    self.current = [self findItem:sender];
    [self reload];
    
    if ([_delegate respondsToSelector:@selector(breadCrumb:didSelect:)]) {
        [_delegate breadCrumb:self didSelect:_current];
    }
}

- (GWMenuItem *) findItem:(UIView *) button {
    for (GWMenuItem *item in _index) {
        if (item.button == button) {
            return item;
        }
    }
    return nil;
}

- (void) dealloc {
    [_index release];
    [_tree release];
    [_current release];
    [_select release];
    [super dealloc];
}
@end
