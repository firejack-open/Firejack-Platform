//
//  GWProperty.m
//  Prometheus
//
//  Created by Администратор on 4/11/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWProperty.h"

@implementation GWProperty

- (id)initWithCoder:(NSCoder *) decoder {
    if (self = [super init]) {
        self.name = [decoder decodeObjectForKey:@"name"];
        self.display = [decoder decodeObjectForKey:@"display"];
        self.defaultValue = [decoder decodeObjectForKey:@"defaultValue"];
        self.constraints = [decoder decodeObjectForKey:@"constraints"];
        self.type = [decoder decodeIntegerForKey:@"type"];
        self.attribute = [decoder decodeIntegerForKey:@"attribute"];
    }
    return self;
}

- (void) encodeWithCoder:(NSCoder *) coder {
    [coder encodeObject:_name forKey:@"name"];
    [coder encodeObject:_display forKey:@"display"];
    [coder encodeObject:_defaultValue forKey:@"defaultValue"];
    [coder encodeObject:_constraints forKey:@"constraints"];
    [coder encodeInteger:_type forKey:@"type"];
    [coder encodeInteger:_attribute forKey:@"attribute"];
}

- (NSString *) stringValue:(id) value {
    id object = [self value:value];
    
    if (_type == GWPropertyTypeEnum)
        return [object valueForKey:@"display"];
    else if (_type == GWPropertyTypeDate)
        return [Util stringFromDate:object];
    else if (_type == GWPropertyTypeTime)
        return [Util stringFromTime:object];
    else if (_type == GWPropertyTypeFullTime)
        return [Util stringFromFullTime:object];
    else if (_type == GWPropertyTypeFlag)
        return [object boolValue] ? FLAG_YES : FLAG_NO;
    else if ([object isKindOfClass:[NSString class]])
        return object;
    else if ([object isKindOfClass:[NSDate class]])
        return [Util stringFromDate:object];
    else if ([object isKindOfClass:[NSNumber class]])
        return [object stringValue];
    
    return object;
}

- (void) setStringValue:(NSString *) value forObject:(id) object {
    if (_attribute == GWPropertyAttributeDefault) {
        id data = value;
        
        if (_type == GWPropertyTypeDate)
            data = [Util dateFromString:value];
        else if (_type == GWPropertyTypeTime)
            data = [Util timeFromString:value];
        else if (_type == GWPropertyTypeFullTime)
            data = [Util fullTimeFromString:value];
        else if (_type == GWPropertyTypeNumber)
            data = @([value longLongValue]);

        [self setValue:data forObject:object];
    }
}


- (id) value:(id) value {
    @try {
        return [value valueForKey:_name];
    } @catch (NSException *e) {
        return nil;
    }
}

- (void) setValue:(id) value forObject:(id) object {
    [object setValue:value forKey:_name];
}

- (id) convertToType:(GWPropertyType) type value:(NSString *) value {
    if (type == GWPropertyTypeDate)
        return [Util dateFromString:value];
    else if (type == GWPropertyTypeTime)
        return [Util timeFromString:value];
    else if (type == GWPropertyTypeFullTime)
        return [Util fullTimeFromString:value];
    else if (type == GWPropertyTypeNumber)
        return @([value longLongValue]);
    else
        return value;
}

- (void)dealloc {
    [_name release];
    [_display release];
    [_defaultValue release];
    [_constraints release];
    [super dealloc];
}

@end
