//
//  GWAssociationPropertyView.m
//  Prometheus
//
//  Created by mjr on 6/27/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWAssociationPropertyView.h"

@implementation GWAssociationPropertyView

- (id) initWithFrame:(CGRect) frame property:(GWProperty *) property {
    self = [super initWithFrame:RectSetHeight(frame, 75) property:property];
    if (self) {
        _multiValue = YES;
    }
    return self;
}

- (void) setValue:(id) value {
    NSMutableArray *list = [self value];
    if (!list) {
        list = [NSMutableArray array];
        [super setValue:list];
    }
    
    [list addObject:value];
    [self addReference:value];
}

- (void) removeObject:(id) value {
    NSMutableArray *list = [self value];
    [list removeObject:value];
    [self removeReference:value];
}

@end
