//
//  GWPasswordPropertyView.m
//  Prometheus
//
//  Created by mjr on 6/27/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWPasswordPropertyView.h"

@implementation GWPasswordPropertyView

- (id) initWithFrame:(CGRect) frame property:(GWProperty *) property {
    self = [super initWithFrame:RectSetHeight(frame, 75) property:property];
    if (self) {
        _textFieldView.secureTextEntry = YES;
    }
    return self;
}

@end
