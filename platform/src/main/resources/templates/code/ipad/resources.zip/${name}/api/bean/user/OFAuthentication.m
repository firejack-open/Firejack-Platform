//
//  OFAuthentication.m
//  Prometheus
//
//  Created by Eugene Maystrenko on 6/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "OFAuthentication.h"

@implementation OFAuthentication

- (id) initWithDictionary:(NSDictionary *) dictionary {
    if (self = [super initWithDictionary:dictionary]) {
		self.token = [Util get:dictionary key:@"token"];
        self.user = [Util getObject:dictionary key:@"user" bean:[OFUser class]];
	}
	return self;
}

- (void) dealloc{
    [_token release];
    [_user release];
    [super dealloc];
}

@end
