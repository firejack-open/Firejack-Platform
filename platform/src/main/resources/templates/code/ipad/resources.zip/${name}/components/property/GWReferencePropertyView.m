//
//  GWReferencePropertyView.m
//  Prometheus
//
//  Created by mjr on 7/25/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWReferencePropertyView.h"

#define indent 8

@implementation GWReferencePropertyView

- (id) initWithFrame:(CGRect) frame property:(GWProperty *) property {
    self = [super initWithFrame:RectSetHeight(frame, 75) property:property];
    if (self) {
        _canvas = [[UIControl alloc] initWithFrame:CGRectMake(0, 25, 625, 50)];
        _canvas.backgroundColor = UIColorFromHex(0xF2FCFF);
        _canvas.layer.cornerRadius = 5;
        _canvas.layer.shadowColor = UIColorFromHex(0xE6EEF2).CGColor;
        _canvas.layer.shadowOffset = CGSizeMake(0, 1);
        _canvas.layer.borderColor = UIColorFromHex(0xC2C8CC).CGColor;
        _canvas.layer.borderWidth = 1;
        [_canvas addTarget:self action:@selector(tap:) forControlEvents:UIControlEventTouchUpInside];
        [_canvas addTarget:self action:@selector(removeReference:forEvent:) forControlEvents:UIControlEventTouchDownRepeat];
        [self addSubview:_canvas];
        [_canvas release];
    
        UILongPressGestureRecognizer *recognizer = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(clearAll:)];
        recognizer.minimumPressDuration = 1.5;
        [_canvas addGestureRecognizer:recognizer];
        [recognizer release];
        
        _maxWidth = ViewWidth(_canvas) - 2*indent;
        
        _references = [[NSMutableArray alloc] init];
        _referenceView = [[NSMutableDictionary alloc] init];
    }
    return self;
}

- (void) layout {
    [_canvas.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    CGFloat y = indent;
    
    NSMutableArray *temp = [_references mutableCopy];
    NSMutableArray *remove = [[NSMutableArray alloc] initWithCapacity:[temp count]];
    
    while ([temp count] != 0) {
        CGFloat x = indent;
        
        GWEntity *entity = [temp objectAtIndex:0];
        GWReferenceView *reference = [self findReferenceView:entity];
        
        [self point:CGPointMake(x, y) reference:reference];
        [_canvas addSubview:reference];
        [remove addObject:entity];
        
        x += ViewWidth(reference) + indent;
        
        for (int i = 1; i < [temp count]; i++) {
            entity = [temp objectAtIndex:i];
            reference = [self findReferenceView:entity];
            
            CGFloat width = ViewWidth(reference);
            if (x + width < _maxWidth) {
                [self point:CGPointMake(x, y) reference:reference];
                [_canvas addSubview:reference];
                [remove addObject:entity];
                x += ViewWidth(reference) + indent;
            }
        }
        
        [temp removeObjectsInArray:remove];
        [remove removeAllObjects];
        y += ViewHeight(reference) + indent;
    }

    [temp release];
    [remove release];
    
    if (y == indent) {
        y = RectHeight(_defaultCanvas);
    }
    
    CGRect frame = _canvas.frame;
    frame.size.height = y;
    _canvas.frame = frame;
    
    frame = self.frame;
    frame.size.height = y + 25;
    self.frame = frame;
    
    if ([self.delegate respondsToSelector:@selector(layout:)]) {
        [self.delegate layout:self];
    }
}

- (void) point:(CGPoint) point reference:(GWReferenceView *) reference {
    CGRect frame = reference.frame;
    frame.origin = point;
    reference.frame = frame;
}

- (GWReferenceView *) findReferenceView:(GWEntity *) entity {
   GWReferenceView *ref = _referenceView[entity];
    if (!ref) {
        ref = [[GWReferenceView alloc] initWithFrame:CGRectZero];
        ref.maxWidth = _maxWidth;
        ref.heading = [_model headingValue:entity];
        ref.subHeading = [_model subHeadingValue:entity];
        ref.description = [_model descriptionValue:entity];
        
        [ref layout];
        
        _referenceView[entity] = ref;
        [ref release];
    }
    return ref;
}

- (void) tap:(id) sender {
    if (!self.selected) {
         self.selected = YES;   
    }
}

- (void) removeReference:(id) sender forEvent:(UIEvent *) event {
    CGPoint point = [[[event allTouches] anyObject] locationInView:_canvas];
    GWEntity *temp = nil;
    for (GWEntity *entity in _references) {
       UIControl *control = _referenceView[entity];
        if (CGRectContainsPoint(control.frame, point)) {
            temp = [entity retain];
            break;
        }
    }
    
    if (temp != nil) {
        [self removeObject:temp];
        [self.sliderView unselect];
        [temp release];
    }
}

- (void)setSelected:(BOOL) selected {
    [super setSelected:selected];
    if (selected) {
        _canvas.layer.borderColor = UIColorFromHex(0x828F99).CGColor;
        _canvas.backgroundColor = [UIColor whiteColor];
        _canvas.layer.borderWidth = 2;
    } else {
        _canvas.layer.borderColor = UIColorFromHex(0xC2C8CC).CGColor;
        _canvas.backgroundColor = UIColorFromHex(0xF2FCFF);
        _canvas.layer.borderWidth = 1;
    }
}

- (void) prepare {
    [super prepare];
    _defaultCanvas = _canvas.frame;
    
    if ([_property isKindOfClass:[GWRelationship class]]) {
        _model = [[(GWRelationship *) _property reference] retain];
    }
    
    [self addReference:[_property value:self.entity]];
}

- (void) addReference:(id) entity {
    if (!entity) return;
    
    if (!_multiValue) {
        [_references removeAllObjects];
        [_referenceView removeAllObjects];
    }

    if (_multiValue && [entity isKindOfClass:[NSArray class]]) {
        [_references addObjectsFromArray:entity];
    } else {
        [_references addObject:entity];
    }
    
    [self layout];
}

- (void) removeReference:(id) entity {
    if (!entity) return;
    [_references removeObject:entity];
    [_referenceView removeObjectForKey:entity];
    [self layout];
}

- (void) clearAll:(UILongPressGestureRecognizer *)recognizer {
    if (recognizer.state == UIGestureRecognizerStateBegan) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Warning" message:@"Remove All ?"
                                                       delegate:self cancelButtonTitle:@"Cancel" otherButtonTitles:@"OK", nil];
        [alert show];
        [alert release];
    }
}

- (void)alertView:(UIAlertView *) alertView clickedButtonAtIndex:(NSInteger)buttonIndex {
    if (buttonIndex == 1) {
        [super removeObject:nil];
        
        [_references removeAllObjects];
        [_referenceView removeAllObjects];
        [self.sliderView deselectAll];
        [self layout];
    }
}

- (void) dealloc {
    [_references release];
    [_referenceView release];
    [_model release];
    [super dealloc];
}
@end
