//
//  GWReferenceView.m
//  Prometheus
//
//  Created by mjr on 7/22/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWReferenceView.h"

@implementation GWReferenceView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = UIColorFromHex(0x2988CC);
        self.userInteractionEnabled = NO;
        self.layer.masksToBounds = YES;
        self.layer.cornerRadius = 4;
        
        _headingLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 10, 0, 24)];
        _headingLabel.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:18];
        _headingLabel.textColor = [UIColor whiteColor];
        _headingLabel.shadowColor = UIColorFromHex(0xE6EEF2);
        _headingLabel.shadowOffset = CGSizeMake(0, 1);
        _headingLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:_headingLabel];
        [_headingLabel release];
	
        _subHeadingLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 30, 0, 19)];
        _subHeadingLabel.font = [UIFont fontWithName:@"HelveticaNeue" size:14];
        _subHeadingLabel.textColor = [UIColor whiteColor];
        _subHeadingLabel.shadowColor = UIColorFromHex(0xE6EEF2);
        _subHeadingLabel.shadowOffset = CGSizeMake(0, 1);
        _subHeadingLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:_subHeadingLabel];
        [_subHeadingLabel release];

        _descriptionLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, 46, 0, 19)];
        _descriptionLabel.font = [UIFont fontWithName:@"HelveticaNeue" size:14];
        _descriptionLabel.textColor = UIColorFromHex(0x78CAFF);
        _descriptionLabel.shadowColor = UIColorFromHex(0xE6EEF2);
        _descriptionLabel.shadowOffset = CGSizeMake(0, 1);
        _descriptionLabel.backgroundColor = [UIColor clearColor];
        [self addSubview:_descriptionLabel];
        [_descriptionLabel release];
    }
    return self;
}

- (void) layout {
    CGFloat width = 0;
    CGFloat max = _maxWidth - 20;
    
    if (_heading) {
        _headingLabel.text = _heading;
        [_headingLabel sizeToFit];
        
        width = MAX(width, ViewWidth(_headingLabel));
        
        [self changeView:_headingLabel width:MIN(width, max)];
    }
    
    if (_subHeading) {
       _subHeadingLabel.text =_subHeading;
        [_subHeadingLabel sizeToFit];

        width = MAX(width, ViewWidth(_subHeadingLabel));
        
        [self changeView:_subHeadingLabel width:MIN(width, max)];
    }
    
    if (_description) {
        _descriptionLabel.text = _description;
        [_descriptionLabel sizeToFit];
        
        width = MAX(width, ViewWidth(_descriptionLabel));
        
        [self changeView:_descriptionLabel width:MIN(width, max)];
    }
    CGRect frame = self.frame;
    frame.size = CGSizeMake(MIN(width + 20, _maxWidth), 72);
    self.frame = frame;
}

- (void) changeView:(UIView *) view width:(CGFloat) width {
    CGRect frame = view.frame;
    frame.size.width = width;
    view.frame = frame;
}

- (void) dealloc {
    [_heading release];
    [_subHeading release];
    [_description release];
    [super dealloc];
}

@end
