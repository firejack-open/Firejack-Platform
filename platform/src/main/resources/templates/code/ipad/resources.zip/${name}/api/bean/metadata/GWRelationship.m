//
//  GWRelationship.m
//  Prometheus
//
//  Created by Администратор on 4/11/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWRelationship.h"

@implementation GWRelationship

- (id)initWithCoder:(NSCoder *) decoder {
    if (self = [super initWithCoder:decoder]) {
        self.target = [decoder decodeObjectForKey:@"target"];
        self.path = [decoder decodeObjectForKey:@"path"];
        self.reference = [decoder decodeObjectForKey:@"reference"];
    }
    return self;
}

- (void) encodeWithCoder:(NSCoder *) coder {
    [super encodeWithCoder:coder];
    
    [coder encodeObject:_target forKey:@"target"];
    [coder encodeObject:_path forKey:@"path"];
    [coder encodeObject:_reference forKey:@"reference"];
}

- (id) stringValue:(id) value {
    if (self.type == GWPropertyTypeObject || self.type == GWPropertyTypeTree) {
        return [[super value:value] valueForKey:_path];
    } else if (self.type == GWPropertyTypeList) {
        return [[super stringValue:value] valueForKey:_path];
    } else {
        return [super stringValue:value];
    }
}

- (id) displayValue:(id) value {
    return [value valueForKey:_path];
}

- (void)dealloc {
    [_target release];
    [_path release];
    [_reference release];
    [super dealloc];
}

@end
