//
//  GWPropertyViewFactory.m
//  Prometheus
//
//  Created by mjr on 6/25/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWPropertyViewFactory.h"

@implementation GWPropertyViewFactory

+ (id) createPropertyView:(CGRect) frame property:(GWProperty *) property {
    switch (property.type) {
        case GWPropertyTypeNumber: return [self createFieldPropertyView:frame property:property];
        case GWPropertyTypeString: return [self createFieldPropertyView:frame property:property];
        case GWPropertyTypeText: return [self createTextPropertyView:frame property:property];
        case GWPropertyTypePassword: return [self createPasswordPropertyView:frame property:property];
        case GWPropertyTypePhoneNumber: return [self createPhoneNumberPropertyView:frame property:property];
        case GWPropertyTypeSSN: return [self createSSNPropertyView:frame property:property];
        case GWPropertyTypeImage: return [self createImagePropertyView:frame property:property];
        case GWPropertyTypeFlag: return [self createFlagPropertyView:frame property:property];
        case GWPropertyTypeDate: return [self createDatePropertyView:frame property:property];
        case GWPropertyTypeTime: return [self createDatePropertyView:frame property:property];
        case GWPropertyTypeFullTime: return [self createDatePropertyView:frame property:property];
        case GWPropertyTypeObject: return [self createObjectPropertyView:frame property:property];
        case GWPropertyTypeEnum: return [self createEnumPropertyView:frame property:property];
        case GWPropertyTypeList: return [self createAssociationPropertyView:frame property:property];
        case GWPropertyTypeTree: return [self createTreePropertyView:frame property:property];
        
        default: return [self createFieldPropertyView:frame property:property];
    }
}

+ (GWFieldPropertyView *) createFieldPropertyView:(CGRect) frame property:(GWProperty *) property {
    return [[[GWFieldPropertyView alloc] initWithFrame:frame property:property] autorelease];
}

+ (GWTextPropertyView *) createTextPropertyView:(CGRect) frame property:(GWProperty *) property {
    return [[[GWTextPropertyView alloc] initWithFrame:frame property:property] autorelease];
}

+ (GWPasswordPropertyView *) createPasswordPropertyView:(CGRect) frame property:(GWProperty *) property {
    return [[[GWPasswordPropertyView alloc] initWithFrame:frame property:property] autorelease];
}

+ (GWPhoneNumberPropertyView *) createPhoneNumberPropertyView:(CGRect) frame property:(GWProperty *) property {
    return [[[GWPhoneNumberPropertyView alloc] initWithFrame:frame property:property] autorelease];
}

+ (GWSSNPropertyView *) createSSNPropertyView:(CGRect) frame property:(GWProperty *) property {
    return [[[GWSSNPropertyView alloc] initWithFrame:frame property:property] autorelease];
}

+ (GWImagePropertyView *) createImagePropertyView:(CGRect) frame property:(GWProperty *) property {
    return [[[GWImagePropertyView alloc] initWithFrame:frame property:property] autorelease];
}

+ (GWDatePropertyView *) createDatePropertyView:(CGRect) frame property:(GWProperty *) property {
    return [[[GWDatePropertyView alloc] initWithFrame:frame property:property] autorelease];
}

+ (GWObjectPropertyView *) createObjectPropertyView:(CGRect) frame property:(GWProperty *) property {
    return [[[GWObjectPropertyView alloc] initWithFrame:frame property:property] autorelease];
}

+ (GWEnumPropertyView *) createEnumPropertyView:(CGRect) frame property:(GWProperty *) property {
    return [[[GWEnumPropertyView alloc] initWithFrame:frame property:property] autorelease];
}

+ (GWAssociationPropertyView *) createAssociationPropertyView:(CGRect) frame property:(GWProperty *) property {
    return [[[GWAssociationPropertyView alloc] initWithFrame:frame property:property] autorelease];
}

+ (GWFlagPropertyView *) createFlagPropertyView:(CGRect) frame property:(GWProperty *) property {
    return [[[GWFlagPropertyView alloc] initWithFrame:frame property:property] autorelease];
}

+ (GWTreePropertyView *) createTreePropertyView:(CGRect) frame property:(GWProperty *) property {
    return [[[GWTreePropertyView alloc] initWithFrame:frame property:property] autorelease];
}

@end
