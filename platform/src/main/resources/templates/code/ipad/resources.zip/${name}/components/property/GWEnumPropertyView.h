//
//  GWEnumPropertyView.h
//  Prometheus
//
//  Created by mjr on 7/2/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWFieldPropertyView.h"
#import "GWEntityPickerView.h"
#import "GWConstraint.h"
#import "GWEnumConstraint.h"

@interface GWEnumPropertyView : GWFieldPropertyView <GWEntityPickerDataSource, GWEntityPickerDelegate> {
    GWEntityPickerView *_entityPiackerView;
    NSArray *_data;
}

@end
