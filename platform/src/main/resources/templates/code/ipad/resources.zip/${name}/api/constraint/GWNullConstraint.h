//
//  GWNullConstraint.h
//  Prometheus
//
//  Created by mjr on 7/4/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWConstraint.h"

@interface GWNullConstraint : GWConstraint

@end
