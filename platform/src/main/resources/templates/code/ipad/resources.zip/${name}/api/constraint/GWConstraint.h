//
//  GWConstraint.h
//  Prometheus
//
//  Created by mjr on 7/3/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GWRuleParameter.h"

@interface GWConstraint : NSObject<NSCoding>

@property (nonatomic, retain) NSString *error;

- (id)initWithConstraint:(GWRuleParameter *) constraint;

- (BOOL) validateValue:(id) value error:(NSString **) message;

@end
