//
//  GWGridCellView.h
//  Prometheus
//
//  Created by Администратор on 3/22/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GWGridCellView : UIControl

@property (nonatomic) NSInteger column;
@property (nonatomic) NSInteger row;

@property (nonatomic, retain) CALayer *backgroundLayer;
@property (nonatomic, retain) CALayer *selectedLayer;

@end
