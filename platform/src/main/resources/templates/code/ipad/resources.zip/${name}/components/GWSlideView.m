//
//  GWSlideView.m
//  Prometheus
//
//  Created by Eugene on 7/23/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWSlideView.h"

@implementation GWSlideView

- (id)initWithFrame:(CGRect)frame  {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
        
        _advancedSearchView = [[GWAdvancedSearchView alloc] initWithFrame:CGRectMake(0, 0, RectWidth(frame), 44)];
        _advancedSearchView.limit = @15;
        _advancedSearchView.delegate = self;
        [self addSubview:_advancedSearchView];
        [_advancedSearchView release];
        
        _tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 44, RectWidth(frame), RectHeight(frame) - 44)];
        _tableView.rowHeight = 75;
        _tableView.dataSource = self;
        _tableView.delegate = self;
        [self addSubview:_tableView];
        [_tableView release];
        
        _indicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
        _indicator.center = CGPointMake(RectWidth(frame)/2.0, _tableView.rowHeight / 2.0);
        _indicator.color = [UIColor grayColor];
        _indicator.layer.cornerRadius = 5;
        [_indicator startAnimating];
    }
    return self;
}

- (void) reload{
    if ([_dataSource respondsToSelector:@selector(slideIsMultipleSelection:)]) {
        _tableView.allowsMultipleSelection = [_dataSource slideIsMultipleSelection:self];
    }
    _advancedSearchView.text = nil;
    [_advancedSearchView reload];
}

- (void) show {
    CGFloat width = ViewWidth(self);
    CGRect frame;
    if (_adjacentView) {
        frame = _adjacentView.frame;
        frame.size.width += _visible ? width: -width;
    }
    
    [UIView animateWithDuration:0.4 delay:0 options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
                         if (_visible) {
                             self.frame = CGRectOffset(self.frame, width, 0);
                         } else {
                             self.frame = CGRectOffset(self.frame, -width, 0);
                         }
                         
                         _adjacentView.frame = frame;
                         [_delegate slide:self visible:_visible];
                         _visible = !_visible;
                     } completion:^(BOOL finished){
                     }];
}

#pragma mark Table Data Source

- (NSInteger)tableView:(UITableView *)table numberOfRowsInSection:(NSInteger) section {
    return _load ? _count + 1: _count;
}

- (UITableViewCell *)tableView:(UITableView *) tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    NSUInteger row = indexPath.row;
    static NSString *CellIdentifier = @"GWSlideCell";
    
    GWSlideCellView *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (!cell) {
        cell = [[[GWSlideCellView alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier] autorelease];
    }
    
    if (row != _count) {
        [_dataSource slide:self cell:cell forRow:row];
        
        if ([_dataSource respondsToSelector:@selector(slide:isSelectedRow:)] && [_dataSource slide:self isSelectedRow:row]) {
            [tableView selectRowAtIndexPath:indexPath
                                   animated:NO
                             scrollPosition:UITableViewScrollPositionNone];
        }
    } else {
        cell.headingLabel.text = nil;
        cell.subHeadingLabel.text = nil;
        cell.descriptionLabel.text = nil;
        [cell addSubview:_indicator];
    }
    
    return cell;
}

- (void) deselectAll {
    for (NSIndexPath *index in [_tableView indexPathsForSelectedRows]) {
        [_tableView deselectRowAtIndexPath:index animated:YES];
    }
}

- (void) unselect {
    if ([_dataSource respondsToSelector:@selector(slide:isSelectedRow:)]){
        for (NSIndexPath *index in [_tableView indexPathsForSelectedRows]) {
            if (![_dataSource slide:self isSelectedRow:index.row]) {
                [_tableView deselectRowAtIndexPath:index animated:YES];
            }
        }
    }
}

#pragma mark Table Delegate

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath {
    if (_count == indexPath.row) {
        [_advancedSearchView next];
    }
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    [_delegate slide:self didSelectForRow:indexPath.row];
}

- (void)tableView:(UITableView *)tableView didDeselectRowAtIndexPath:(NSIndexPath *)indexPath {
    if ([_delegate respondsToSelector:@selector(slide:didDeselectForRow:)]) {
        [_delegate slide:self didDeselectForRow:indexPath.row];
    }
}

#pragma mark -
#pragma mark Advanced Search Delegate

- (void) search:(GWAdvancedSearchView *) search edit:(BOOL) edit {
    CGRect frame = _tableView.frame;
    
    if (edit) {
        frame.size.height -= 350;
    } else {
        frame.size.height += 350;
    }
    _tableView.frame = frame;
}

- (void) search:(GWAdvancedSearchView *) search offset:(NSNumber *)offset limit:(NSNumber *) limit {
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        NSNumber *total = nil;
        [_dataSource slide:self term:search.text offset:offset limit:limit total:&total];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            search.total = total;
            
            _count = [offset intValue] + [limit intValue];
            if (_count > [total intValue]) {
                _count = [total intValue];
            }
            
            [_indicator removeFromSuperview];
            
            _load = _count < [total intValue];
            [_tableView reloadData];
        });
    });
}

- (void)dealloc {
    [_adjacentView release];
    [_indicator release];
    [super dealloc];
}

@end
