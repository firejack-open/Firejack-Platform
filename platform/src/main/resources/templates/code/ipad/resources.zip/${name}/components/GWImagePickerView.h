//
//  GWImagePickerView.h
//  Prometheus
//
//  Created by mjr on 5/2/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ASIHTTPRequest.h"
#import "UIImage+Utils.h"
#import "OFImageFile.h"

typedef NS_ENUM(NSInteger, GWImagePickerStatus) {
    GWImagePickerStatusLoad,
    GWImagePickerStatusUpload,
    GWImagePickerStatusUpdate,
    GWImagePickerStatusDelete
};

@protocol GWImagePickerDelegate;

@interface GWImagePickerView : UIView<UIActionSheetDelegate ,UINavigationControllerDelegate, UIImagePickerControllerDelegate, ASIHTTPRequestDelegate> {
    UIPopoverController *_popover;
    UIImagePickerController *_imagePickerController;
    UIViewController *_imageController;
    UIButton *_preview;
    UIImage *_defaultImage;
}

@property (nonatomic, assign) id<GWImagePickerDelegate> delegate;
@property (nonatomic, retain) UIImageView *imageView;
@property (nonatomic, retain) OFImageFile *file;
@property (nonatomic, retain) NSString *lookup;
@property (nonatomic, readonly) GWImagePickerStatus status;

@end

@protocol GWImagePickerDelegate <NSObject>

- (void) loadImage:(GWImagePickerView *) view lookup:(NSString *) lookup;
- (void) uploadImage:(GWImagePickerView *) view image:(UIImage *) image;

@end