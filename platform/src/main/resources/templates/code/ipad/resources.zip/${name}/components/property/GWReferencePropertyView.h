//
//  GWReferencePropertyView.h
//  Prometheus
//
//  Created by mjr on 7/25/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWPropertyView.h"
#import "GWReferenceView.h"

@interface GWReferencePropertyView : GWPropertyView<UIAlertViewDelegate> {
    UIControl *_canvas;
    GWModel *_model;
    NSMutableArray *_references;
    NSMutableDictionary *_referenceView;
    CGFloat _maxWidth;
    CGRect _defaultCanvas;
    BOOL _multiValue;
}

- (void) addReference:(id) entity;
- (void) removeReference:(id) entity;

@end
