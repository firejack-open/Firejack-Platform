//
//  GWLoginController.h
//  Prometheus
//
//  Created by Администратор on 2/22/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GWTextFieldView.h"
#import "GWBaseViewController.h"
#import "GWMenuViewController.h"

@interface GWLoginController : GWBaseViewController <UITextFieldDelegate>

@property (nonatomic, retain) IBOutlet GWTextFieldView *username;
@property (nonatomic, retain) IBOutlet GWTextFieldView *password;

@end
