//
//  GWImagePickerView.m
//  Prometheus
//
//  Created by mjr on 5/2/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWImagePickerView.h"

@implementation GWImagePickerView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _defaultImage = [[UIImage imageNamed:@"edit_default"] retain];
        
        _preview = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 90, 90)];
        _preview.layer.cornerRadius = 4;
        [_preview setBackgroundImage:_defaultImage forState:UIControlStateNormal];
        [_preview addTarget:self action:@selector(choise:) forControlEvents:UIControlEventTouchUpInside];
        [self addSubview:_preview];
        [_preview release];

        _imageController = [[UIViewController alloc] init];
        _imageView = [[UIImageView alloc] init];
        _imageController.view = _imageView;
        [_imageView release];
        
        _imagePickerController = [[UIImagePickerController alloc] init];
        _imagePickerController.delegate = self;
        _imagePickerController.allowsEditing = YES;
        
        _popover = [[UIPopoverController alloc] initWithContentViewController:_imagePickerController];
    }
    return self;
}

- (void) setLookup:(NSString *)lookup {
    [_lookup release];
    _lookup = [lookup retain];
    _status = GWImagePickerStatusLoad;
    
    if (lookup && [_delegate respondsToSelector:@selector(loadImage:lookup:)]) {
        [_delegate loadImage:self lookup:lookup];
    }
}

- (void) choise:(id)sender {
    NSString *fullPreview = _imageView.image ? @"Full Preview": nil;
    
    UIActionSheet *popupQuery = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:nil destructiveButtonTitle:nil otherButtonTitles:@"Take Photo", @"Choose Photo", fullPreview, @"Delete Photo", nil];
    popupQuery.actionSheetStyle = UIActionSheetStyleBlackOpaque;
    [popupQuery showInView:self];
    [popupQuery release];
}

- (void) preview:(UIButton *) sender {    
    _popover.popoverContentSize = _imageView.image.size;
    _popover.contentViewController = _imageController;
    
    [_popover presentPopoverFromRect:CGRectMake(30, 30, 0, 0) inView:self permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
}

-(void) actionSheet:(UIActionSheet *) actionSheet clickedButtonAtIndex:(NSInteger) buttonIndex {
	if (buttonIndex == 0) {
		[self open:UIImagePickerControllerSourceTypeCamera];
	} else if (buttonIndex == 1) {
		[self open:UIImagePickerControllerSourceTypePhotoLibrary];
    } else if (buttonIndex == 2) {
        [self preview:nil];
	} else if (buttonIndex == 3) {
		[self deletePhoto];
	}
}

- (void) open:(UIImagePickerControllerSourceType) type {
	if ([UIImagePickerController isSourceTypeAvailable:type]){
        _popover.contentViewController = _imagePickerController;
        _imagePickerController.sourceType = type;
        
        [_popover presentPopoverFromRect:CGRectMake(30, 30, 0, 0) inView:self permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
	}
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info {
	[picker dismissViewControllerAnimated:YES completion:^{}];
	
	_imageView.image = (UIImage *) [info objectForKey:UIImagePickerControllerOriginalImage];
    [_preview setBackgroundImage:_imageView.image forState:UIControlStateNormal];
    
    if ([_delegate respondsToSelector:@selector(uploadImage:image:)]) {
        [_delegate uploadImage:self image:_imageView.image];
    }
    
    [_popover dismissPopoverAnimated:YES];
    _status = _lookup == nil ? GWImagePickerStatusUpload : GWImagePickerStatusUpdate;
}

- (void) deletePhoto {
    _imageView.image = nil;
    [_preview setBackgroundImage:_defaultImage forState:UIControlStateNormal];
    _status = GWImagePickerStatusDelete;
}

- (void)requestFinished:(ASIHTTPRequest *) request {
    NSData *responseData = [request responseData];
    UIImage *image = [UIImage imageWithData:responseData];
    _imageView.image = image;
    [_preview setBackgroundImage:image forState:UIControlStateNormal];
    
    [self release];
}

- (void)dealloc {
    [_defaultImage release];
    [_popover release];
    [_imagePickerController release];
    [_imageController release];
    [_file release];
    [_lookup release];
    [super dealloc];
}

@end
