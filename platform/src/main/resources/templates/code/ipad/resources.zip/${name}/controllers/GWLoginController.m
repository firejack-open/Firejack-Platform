//
//  GWLoginController.m
//  Prometheus
//
//  Created by Администратор on 2/22/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWLoginController.h"

@interface GWLoginController ()

@end

@implementation GWLoginController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil {
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

- (void) viewWillAppear:(BOOL)animated {
    self.navigationController.navigationBarHidden = YES;
    NSString *username = [Util getProperty:USERNAME];
    NSString *password = [Util getProperty:PASSWORD];
    
    _username.text = username;
    _password.text = [Util getProperty:PASSWORD_HINT];
    
    if (password) {
        [self login:username password:password];
    }

    [super viewWillAppear:animated];
}

- (void)viewDidLoad {
    UIView *login = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"l_login_f"] highlightedImage:[UIImage imageNamed:@"l_login_a"]];
    UIView *password = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"l_password_f"] highlightedImage:[UIImage imageNamed:@"l_password_a"]];
    
    _username.leftView = login;
    _username.leftViewMode = UITextFieldViewModeAlways;
    _username.layer.borderColor = RGB(180, 200, 205).CGColor;
    _username.layer.borderWidth = 1;
    _username.layer.cornerRadius = 4;
    _username.dx = 40;
    _username.leftIcon = CGRectMake(10, 10, 20, 20);
    _username.rightIcon = CGRectMake(274, 7, 16, 16);
    
    _password.leftView = password;
    _password.leftViewMode = UITextFieldViewModeAlways;
    _password.layer.borderColor = RGB(180, 200, 205).CGColor;
    _password.layer.borderWidth = 1;
    _password.layer.cornerRadius = 4;
    _password.dx = 40;
    _password.leftIcon = CGRectMake(10, 10, 20, 20);
    _password.rightIcon = CGRectMake(274, 7, 16, 16);
    [login release];
    [password release];
    
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction) login:(id)sender {
    [self login:_username.text password:_password.text];
}

- (void) login:(NSString *) username password:(NSString *) password {
    OFAuthentication *auth = [self.api login:username password:password];
    if (auth) {
        [self.delegate.modelManager loadRules];
        
        GWMenuViewController *controller = [[GWMenuViewController alloc] init];
        [self.navigationController pushViewController:controller animated:YES];
        [controller release];
    }
}

- (IBAction) registerUser:(id) sender {
}
- (IBAction) forgotPassword:(id) sender {
}

- (BOOL) textFieldShouldBeginEditing:(UITextField *) textField {
    textField.layer.borderColor = RGB(115, 160, 190).CGColor;
    ((UIImageView *) textField.leftView).highlighted = YES;
    return YES;
}

- (void) textFieldDidEndEditing:(UITextField *) textField {
    textField.layer.borderColor = RGB(180, 200, 205).CGColor;
    ((UIImageView *) textField.leftView).highlighted = NO;
}

- (BOOL) textFieldShouldReturn:(UITextField *) textField {
    [textField resignFirstResponder];
    return YES;
}

- (void) dealloc {
    [super dealloc];
}

@end
