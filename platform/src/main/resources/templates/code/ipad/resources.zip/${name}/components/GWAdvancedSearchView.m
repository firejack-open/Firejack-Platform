//
//  GWAdvancedSearchView.m
//  Prometheus
//
//  Created by mjr on 7/29/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWAdvancedSearchView.h"

@implementation GWAdvancedSearchView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        self.backgroundColor = UIColorFromHex(0x294766);
        
        UIView *searchIcon = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"edit_search"]];
        
        _searchFieldView = [[GWTextFieldView alloc] initWithFrame:CGRectMake(6, 6, RectWidth(frame) - 12, RectHeight(frame) - 12)];
        _searchFieldView.font = [UIFont fontWithName:@"HelveticaNeue" size:15];
        _searchFieldView.placeholder = @"Search";
        _searchFieldView.dx = 30;
        _searchFieldView.dy = 5;
        _searchFieldView.leftIcon = CGRectMake(8, 8, 14, 14);
        _searchFieldView.textColor = UIColorFromHex(0x7F7F7F);
        _searchFieldView.keyboardType = UIKeyboardTypeNumberPad;
        _searchFieldView.returnKeyType = UIReturnKeySearch;
        _searchFieldView.backgroundColor = [UIColor whiteColor];
        _searchFieldView.layer.cornerRadius = 3;
        _searchFieldView.leftView = searchIcon;
        _searchFieldView.leftViewMode = UITextFieldViewModeAlways;
        _searchFieldView.clearButtonMode = UITextFieldViewModeAlways;
        _searchFieldView.delegate = self;
        [self addSubview:_searchFieldView];
        [_searchFieldView release];
        [searchIcon release];

    }
    return self;
}

- (void) reload {
    if (!_text) {
        _searchFieldView.text = nil;
    }
    if (_limit) {
        _offset = 0;
        [_delegate search:self offset:@(_offset) limit:_limit];
    }
}

- (void) next {
    _offset += [_limit intValue];
    [_delegate search:self offset:@(_offset) limit:_limit];
}

- (void)dealloc {
    [_limit release];
    [_total release];
    [_text release];
    [super dealloc];
}

#pragma mark -
#pragma mark Search Delegate

- (BOOL)textFieldShouldClear:(UITextField *) textField {
    self.text = nil;
    [self reload];
    
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *) textField {
    NSString *text = textField.text;
    self.text = text.length != 0 ? text: nil;
    [self reload];
       
    return [textField resignFirstResponder];
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    if ([_delegate respondsToSelector:@selector(search:edit:)]) {
        [_delegate search:self edit:YES];
    }
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    if ([_delegate respondsToSelector:@selector(search:edit:)]) {
        [_delegate search:self edit:NO];
    }
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    self.text = [textField.text stringByReplacingCharactersInRange:range withString:string];
    if (_text.length > 1) {
        [self reload];
    }
    return YES;
}

@end
