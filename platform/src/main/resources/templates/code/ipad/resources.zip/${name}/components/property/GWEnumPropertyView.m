//
//  GWEnumPropertyView.m
//  Prometheus
//
//  Created by mjr on 7/2/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWEnumPropertyView.h"

@implementation GWEnumPropertyView

- (id) initWithFrame:(CGRect) frame property:(GWProperty *) property {
    self = [super initWithFrame:RectSetHeight(frame, 75) property:property];
    if (self) {
        _entityPiackerView = [[GWEntityPickerView alloc] initWithFrame:CGRectMake(0, 704, 1024, 262)];
        _entityPiackerView.type = GWEntityPickerTypeSingleSelect;
        
        NSArray *constraints = _property.constraints;
        for (GWConstraint *constraint in constraints) {
            if ([constraint isKindOfClass:[GWEnumConstraint class]]) {
                _data = [[(GWEnumConstraint *) constraint values] retain];
            }
        }
    }
    return self;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    [self.mainView endEditing:YES];
    self.selected = !self.selected;
    return NO;
}

- (void) setSelected:(BOOL) selected {
    [super setSelected:selected];
    
    if (selected) {
        [self.mainView addSubview:_entityPiackerView];
        [_entityPiackerView reload];
    }
    
    [self show:selected];
}

- (void) show:(BOOL) show {
    [UIView animateWithDuration:0.4 delay:0 options:UIViewAnimationOptionCurveEaseInOut
                     animations:^{
                         if (show) {
                             _entityPiackerView.frame = CGRectOffset(_entityPiackerView.frame, 0, -ViewHeight(_entityPiackerView));
                         } else {
                             _entityPiackerView.frame = CGRectOffset(_entityPiackerView.frame, 0,  ViewHeight(_entityPiackerView));
                         }
                     } completion:^(BOOL finished){
                         if (!show) {
                             [_entityPiackerView removeFromSuperview];
                         }
                     }];
}

- (void) prepare {
    [super prepare];
    _entityPiackerView.dataSource = self;
    _entityPiackerView.delegate = self;
}

#pragma mark -
#pragma mark EntityPicker Data Source

- (void) picker:(GWEntityPickerView *) picker offset:(NSNumber *) offset limit:(NSNumber *) limit total:(NSNumber **) total {
    *total = @([_data count]);
}

- (NSString *) picker:(GWEntityPickerView *) picker titleForRow:(NSUInteger) row {
    return [(GWEnum *)[_data objectAtIndex:row] display];
}

#pragma mark -
#pragma mark EntityPicker Delegate

- (void) picker:(GWEntityPickerView *) picker didSelectForRow:(NSUInteger) row {
    GWEnum *_enum = [_data objectAtIndex:row];
    [super setValue:_enum];
     _textFieldView.text = _enum.display;
}

- (void)dealloc {
    [_data release];
    [super dealloc];
}
@end
