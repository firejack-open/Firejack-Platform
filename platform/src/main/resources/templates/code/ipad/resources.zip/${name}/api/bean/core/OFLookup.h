//
//  OFLookup.h
//  Prometheus
//
//  Created by Eugene Maystrenko on 7/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "OFTreeNode.h"

@interface OFLookup : OFTreeNode

@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSString *path;
@property (nonatomic, retain) NSString *lookup;
@property (nonatomic, retain) NSString *type;
@property (nonatomic, retain) NSString *info;

@end
