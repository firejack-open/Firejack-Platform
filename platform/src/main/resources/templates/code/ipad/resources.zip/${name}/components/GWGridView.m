		//
//  Util.m
//  Prometheus
//
//  Created by Eugene Maystrenko on 3/20/13.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "GWGridView.h"

#define PADDING 1

@implementation GWGridView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        _cellPool = [[NSMutableSet alloc] init];
        _headers = [[NSMutableArray alloc] init];
        _columns = [[NSMutableArray alloc] init];
        _rows = [[NSMutableArray alloc] init];
        self.backgroundColor = [UIColor whiteColor];
        
        _scrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, frame.size.width, frame.size.height - 46)];
        _scrollView.delegate = self;
        _scrollView.bounces = NO;
        _scrollView.backgroundColor = [UIColor lightGrayColor];
        [self addSubview:_scrollView];
        [_scrollView release];
        
        _paging = [[GWPagingView alloc] initWithFrame:CGRectMake(0, frame.size.height - 46, frame.size.width, 46)];
        _paging.limit = @15;
        [self addSubview:_paging];
        [_paging release];
        
        _states = [[NSMutableArray alloc] initWithCapacity:50];
    }
    
    return self;
}

- (void)dealloc {
    [_total release];
    [_limit release];
    [_cellPool release];
    [_headers release];
    [_columns release];
    [_rows release];
    [_states release];
    [super dealloc];
}

- (void) setDelegate:(id<GWGridDelegate, GWPagingDelegate>) delegate {
    _delegate = delegate;
    _paging.delegate = delegate;
}

- (void) setTotal:(NSNumber *) total {
    [_total release];
    _total = [total retain];
    _paging.total = total;
}

- (void) setLimit:(NSNumber *)limit {
    [_limit release];
    _limit = [limit retain];
    _paging.limit = limit;
}

- (void) refresh {
    [_paging reload];
}

- (void)reloadData {
    for (UIView *view in _scrollView.subviews) {
        if ([view isKindOfClass:[GWGridCellView class]]) {
            [view.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
            [_cellPool addObject:view];
        }
    }
    
    [_scrollView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [_headers removeAllObjects];
    [_columns removeAllObjects];
    [_rows removeAllObjects];
    
    _area = CGSizeMake(0, 0);
    
    NSInteger numColumns = [_dataSource numberOfColumns:self];
    NSInteger numRows = [_dataSource numberOfRow:self];
    CGFloat headerHeight = 0;
    CGFloat cellHeight = 40;
    
    if ([_dataSource respondsToSelector:@selector(headerHeight:)]) {
        headerHeight = [_dataSource headerHeight:self];
    }
    
    CGFloat width = ViewWidth(self) / MIN(numColumns, 5);
    
    CGRect frame = CGRectMake(0, 0, 0, headerHeight);
    
    for (int i = 0; i < numColumns; i++) {
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap:)];
        tap.numberOfTapsRequired = 2;
        
        UIPanGestureRecognizer *resize = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(resize:)];
        resize.maximumNumberOfTouches = 2;
        
        UIView *column = [[UIView alloc] initWithFrame:frame];
        
        [column addGestureRecognizer:resize];
        [column addGestureRecognizer:tap];
        
        [resize release];
        [tap release];
        
        CAGradientLayer *layer = [CAGradientLayer layer];
        layer.colors = [NSArray arrayWithObjects:(id) UIColorFromHex(0x4C6680).CGColor, (id) UIColorFromHex(0x364459).CGColor, nil];
        layer.frame = CGRectMake(0, 0, ViewWidth(self), headerHeight);
        [column.layer insertSublayer:layer atIndex:0];
        column.clipsToBounds = YES;

        if ([_dataSource respondsToSelector:@selector(cellWidth:atColumn:)]) {
            width = [_dataSource cellWidth:self atColumn:i];
        }
                
        frame.origin.x += frame.size.width + PADDING;
        frame.size.width = width;
        column.frame = frame;
        
        _states[i] = [NSValue valueWithGWSate:GWMakeState(RectX(frame), width)];
        _area.width += width + PADDING;

        if ([_dataSource respondsToSelector:@selector(header:view:column:)]) {
            [_dataSource header:self view:column column:i];
        }
        
        [_headers addObject:column];
        [_scrollView addSubview:column];
        [column release];
    }
    
    if ([_dataSource respondsToSelector:@selector(cellHeight:)]) {
        cellHeight = [_dataSource cellHeight:self];
    }
    
    _area.height = numRows * (cellHeight + PADDING);
    
    frame.origin.y += headerHeight;
    frame.size.height = cellHeight;
    
    NSArray *backgroundColors = [NSArray arrayWithObjects:(id) UIColorFromHex(0xF7F7F7).CGColor, (id) UIColorFromHex(0xEDEDED).CGColor, nil];
    NSArray *selectColors = [NSArray arrayWithObjects:(id) UIColorFromHex(0xF2fAFF).CGColor, (id) UIColorFromHex(0xD9EFFF).CGColor, nil];
    
    for (int i = 0; i < numRows; i++) {
        for (int j = 0; j < numColumns; j++) {
             GWState state = [_states[j] stateValue];
            frame.origin.x = state.x;
            frame.size.width = state.width;
            
            GWGridCellView *cell = [_dataSource view:self viewFoRow:i column:j];
            
            cell.frame = frame;
            
            if (!cell.backgroundLayer) {
                CAGradientLayer *layer = [CAGradientLayer layer];
                layer.colors = backgroundColors;
                layer.frame = CGRectMake(0, 0, ViewWidth(self), cellHeight);
                cell.backgroundLayer = layer;
                [cell.layer insertSublayer:layer atIndex:0];
                cell.backgroundColor = [UIColor whiteColor];
                cell.clipsToBounds = YES;
                [cell addTarget:self action:@selector(selectCell:) forControlEvents:UIControlEventTouchUpInside];
            }

            if (!cell.selectedLayer) {
                CAGradientLayer *layer = [CAGradientLayer layer];
                layer.colors = selectColors;
                layer.frame = CGRectMake(0, 0, ViewWidth(self), cellHeight);
                layer.borderWidth = 0.6;
                cell.selectedLayer = layer;
                [cell.layer insertSublayer:layer atIndex:1];
            }
            
            cell.column = j;
            cell.row = i;
            cell.selected = NO;
            
            [self setCell:cell toRowIndex:i toColumnIndex:j];
            [_scrollView addSubview:cell];
        }
        frame.origin.y += cellHeight + PADDING ;
    }
    
    for (UIView *header in _headers) {
        [self bringSubviewToFront:header];
    }
    
    [_scrollView setContentSize:_area];
    [_scrollView setNeedsLayout];
}

- (GWGridCellView *) dequeueReusableCell {
    GWGridCellView *view = [[[_cellPool anyObject] retain] autorelease];
    if (view) {
        [_cellPool removeObject:view];
    }
    
    return view;
}

- (void) setCell:(UIView *) cell toRowIndex:(NSUInteger) rowIndex toColumnIndex:(NSUInteger) columnIndex {
    NSMutableArray *cells = [_columns count] > columnIndex ? [_columns objectAtIndex:columnIndex]: nil;
    if(!cells) {
        cells = [NSMutableArray array];
        [_columns setObject:cells atIndexedSubscript:columnIndex];
    }
    [cells addObject:cell];
    
    cells = [_rows count] > rowIndex ? [_rows objectAtIndex:rowIndex]: nil;
    if(!cells) {
        cells = [NSMutableArray array];
        [_rows setObject:cells atIndexedSubscript:rowIndex];
    }
    [cells addObject:cell];
}

- (void)scrollViewDidScroll:(UIScrollView *)sender {
    CGFloat y = sender.contentOffset.y;
    for (UIView *header in _headers) {
        CGRect frame = header.frame;
        frame.origin.y = y;
        header.frame = frame;
    }
}

- (void) resize:(UIPanGestureRecognizer *) sender {
    if (sender.state == UIGestureRecognizerStateBegan) {
        CGPoint touch = [sender locationInView:sender.view];
        _selectColumn = [_headers indexOfObject:sender.view];
        _selectDelta = ViewWidth(sender.view) - touch.x;
    }
    
    if (sender.numberOfTouches == 1) {
        UIView *header = [_headers objectAtIndex:_selectColumn];
        CGPoint touch = [sender locationInView:header];
        CGRect cellFrame = header.frame;
        CGFloat width = touch.x + _selectDelta;
        CGFloat delta = cellFrame.size.width - width;
        
        if (width <= 30 || width >= ViewWidth(self)) return;
        for (int i = _selectColumn; i < [_headers count]; i++) {
            UIView *header = [_headers objectAtIndex:i];
            cellFrame = header.frame;
            if (i == _selectColumn) {
                cellFrame.size.width = width;
            } else {
                cellFrame.origin.x -= delta;
            }
            header.frame = cellFrame;
        }
        
        for (int i = _selectColumn; i < [_columns count]; i++) {
            NSArray *cells = [_columns objectAtIndex:i];
            for (UIView *cell in cells) {
                cellFrame = cell.frame;
                if (i == _selectColumn) {
                    cellFrame.size.width = width;
                } else {
                    cellFrame.origin.x -= delta;
                }
                cell.frame = cellFrame;
            }
        }
        
        _area.width -= delta;
        delta = ViewWidth(self) - _area.width;
        if (delta > 0) {
            NSUInteger last = [_headers count] -1;
            UIView *header = [_headers objectAtIndex:last];
            CGRect frame = header.frame;
            frame.size.width += delta;
            header.frame = frame;
            
            NSArray *cells = [_columns objectAtIndex:last];
            for (UIView *cell in cells) {
                frame = cell.frame;
                frame.size.width += delta;
                cell.frame = frame;
            }
            _area.width += delta;
        }
        
        [_scrollView setContentSize:_area];
    }
}

- (void) selectCell:(GWGridCellView *) sender {
    NSArray *cells = [_rows objectAtIndex:_selectRow];
    for (GWGridCellView *cell in cells) {
        cell.selected = NO;
    }
    
    _selectColumn = sender.column;
    _selectRow = sender.row;
    
    _selectCell = sender;
    
    if ([_delegate respondsToSelector:@selector(selectCell:atRow:atColumn:)]) {
        [_delegate selectCell:self atRow:_selectRow atColumn:_selectColumn];
    }
    
    if ([_delegate respondsToSelector:@selector(selectCell:atCell:)]) {
        [_delegate selectCell:self atCell:sender];
    }
    
     cells = [_rows objectAtIndex:_selectRow];
    for (GWGridCellView *cell in cells) {
        cell.selected = YES;
    }
}

- (void) tap:(UITapGestureRecognizer *) sender {
        _area.width = 0;
        CGRect frame;
        
        for (int i = 0; i < [_headers count]; i++) {
            UIView *header = _headers[i];
            GWState state = [_states[i] stateValue];
            frame = header.frame;
            frame.origin.x = state.x + PADDING;
            frame.size.width = state.width;
            header.frame = frame;
            _area.width += state.width + PADDING;
            
            NSArray *cells = [_columns objectAtIndex:i];
            for (UIView *cell in cells) {
                frame = cell.frame;
                frame.origin.x = state.x + PADDING;
                frame.size.width = state.width;
                cell.frame = frame;
            }
        }
        
        [_scrollView setContentSize:_area];
}

@end

@implementation NSValue ( NSValueSateExtensions )

+ (NSValue *) valueWithGWSate:(GWState) state {
    return [NSValue value:&state withObjCType:@encode(GWState)];
}

- (GWState) stateValue {
    GWState state;
    [self getValue:&state];
    return state;
}

@end