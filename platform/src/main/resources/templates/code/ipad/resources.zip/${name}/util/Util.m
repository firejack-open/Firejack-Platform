//
//  Util.m
//  Prometheus
//
//  Created by Eugene Maystrenko on 6/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "Util.h"
#import "GWRequest.h"

static NSString *letters = @"abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
static NSDateFormatter *_dateFormatter;
static NSDateFormatter *_timeFormatter;
static NSDateFormatter *_fullTimeFormatter;
static NSRegularExpression *_regex;
static NSUserDefaults *_userDefaults;
static float _version;

@implementation Util

+ (void)initialize {
     _regex = [[NSRegularExpression alloc] initWithPattern:@"\\{(.*?)\\}" options:NSRegularExpressionCaseInsensitive error:nil];
    _userDefaults = [NSUserDefaults standardUserDefaults];
     _dateFormatter = [[NSDateFormatter alloc] init];
    [_dateFormatter setDateFormat:@"MM-dd-yyyy"];
     _timeFormatter = [[NSDateFormatter alloc] init];
    [_timeFormatter setDateFormat:@"hh:mm aaa"];
     _fullTimeFormatter = [[NSDateFormatter alloc] init];
    [_fullTimeFormatter setDateFormat:@"MM-dd-yyyy HH:mm:ss aaa"];
    _version = [[[UIDevice currentDevice] systemVersion] floatValue];
}

+ (BOOL) isIOS5 {
    return  _version >= 5.0;
}

+ (BOOL) isIOS6 {
    return  _version >= 6.0;
}

+ (BOOL) isIOS7 {
    return  _version >= 7.0;
}

+ (BOOL) isNumber:(NSString *) string {
    NSCharacterSet* nonNumbers = [[NSCharacterSet decimalDigitCharacterSet] invertedSet];
    return [string rangeOfCharacterFromSet: nonNumbers].location == NSNotFound;
}

+ (NSString *) append:(NSString *) first, ... {
    NSString *result = first;
    NSObject *temp;
    va_list alist;
    
    va_start(alist, first);
    while ((temp = va_arg(alist, id)))
        if ([temp isKindOfClass:[NSNumber class]]) {
            result = [result stringByAppendingString:[(NSNumber *) temp stringValue]];
        } else {
            result = [result stringByAppendingString:(NSString *) temp];
        }
    va_end(alist);
    
    return result;
}

#pragma mark -
#pragma mark Serialize / Deserialize

+ (void) addList:(NSMutableDictionary *) dic list:(NSArray *) list key:(NSString *) key {
    if (list) {
        NSMutableArray *temp = [NSMutableArray array];
        for (GWSerializable *item in list) {
            [temp addObject:[item dictionary]];
        }
        [dic setObject:temp forKey:key];
    }
    
}


+ (id) getList:(NSDictionary *)dic key:(NSString *)key bean:(Class) bean {
    NSArray *list = [self get:dic key:key];
    if(list && list.count != 0) {
        NSMutableArray *temp = [NSMutableArray array];
        for (NSDictionary *item in list) {
            GWSerializable *value = [[bean alloc] initWithDictionary:item];
            [temp addObject:value];
            [value release];
        }
        return temp;
    }
    return nil;
    
}

+ (void) add:(NSMutableDictionary *) dic value:(id) value key:(NSString *) key {
    if (value) {
        [dic setObject:value forKey:key];
    }
}

+ (id) get:(NSDictionary *) dic key:(NSString *) key {
    id value = [dic objectForKey:key];
    if (value && value != [NSNull null]) {
        return value;
    }
    return nil;
}

+ (id) getObject:(NSDictionary *) dic key:(NSString *) key bean:(Class) bean {
    NSDictionary *data = [self get:dic key:key];
    if (data) {
        return [[[bean alloc] initWithDictionary:data] autorelease];
    }
    return nil;
}

+ (NSDate *) getDate:(NSDictionary *) dic key:(NSString *) key {
    NSNumber *date = [self get:dic key:key];
    return date ? [NSDate dateWithTimeIntervalSince1970:[date doubleValue] / 1000] : nil;
}

+ (void) addDate:(NSMutableDictionary *) dic date:(NSDate *) date key:(NSString *) key {
    if (date) {
        [dic setObject:@([date timeIntervalSince1970] * 1000) forKey:key];
    }
}

+ (GWEnum *) getEnum:(NSDictionary *) dic key:(NSString *) key {
    return [self getObject:dic key:key bean:[GWEnum class]];
}

+ (void) addEnum:(NSMutableDictionary *) dic value:(GWEnum *) value key:(NSString *) key {
    if (value) {
        [dic setObject:value.name forKey:key];
    }
}

+ (BOOL) getBool:(NSDictionary *) dic key:(NSString *) key {
    NSNumber *num = [self get:dic key:key];
    return num ? [num boolValue] : NO;
}

+ (void) addBool:(NSMutableDictionary *) dic value:(BOOL) value key:(NSString *) key {
    [dic setObject:@(value) forKey:key];
}

+ (NSString *) serialize:(id) obj {
    
    GWRequest *request = [[GWRequest alloc] init];
    request.data = obj;
    NSDictionary *dic = [request dictionary];
    
    NSError *error = nil;
    NSData *data = [NSJSONSerialization dataWithJSONObject:dic options:NSJSONWritingPrettyPrinted error:&error];
    [request release];
    
    return [[[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding] autorelease];
}

+ (NSDictionary *) deserialize:(NSString *)string {
    if (string.length == 0) return [NSDictionary dictionary];
    
    NSError * error = nil;
    NSData * data = [string dataUsingEncoding:NSUTF8StringEncoding];
    return [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:&error];
}

#pragma mark -
#pragma mark User Property

+ (void)setProperty:(NSString *)key value:(id) value {
    [_userDefaults setObject:value forKey:key];
    [_userDefaults synchronize];
}

+ (void)setBoolProperty:(NSString *)key value:(BOOL) value {
    [_userDefaults setBool:value forKey:key];
    [_userDefaults synchronize];
}

+ (void)removeProperty:(NSString *) key {
    [_userDefaults removeObjectForKey:key];
    [_userDefaults synchronize];
}

+ (NSString *)getProperty:(NSString *) key {
    return [_userDefaults stringForKey:key];
}

+ (BOOL)getBoolProperty:(NSString *) key {
    return [_userDefaults boolForKey:key];
}

+ (NSDate *) dateFromString:(NSString *) value {
    return [_dateFormatter dateFromString:value];
}

+ (NSString *) stringFromTime:(NSDate *) date {
    return [_timeFormatter stringFromDate:date];
}

+ (NSDate *) timeFromString:(NSString *) value {
    return [_timeFormatter dateFromString:value];
}

+ (NSString *) stringFromDate:(NSDate *) date {
    return [_dateFormatter stringFromDate:date];
}

+ (NSDate *) fullTimeFromString:(NSString *) value {
    return [_fullTimeFormatter dateFromString:value];
}

+ (NSString *) stringFromFullTime:(NSDate *) date {
    return [_fullTimeFormatter stringFromDate:date];
}

+ (NSString *) timeFormat: (float) seconds {
    int hours = seconds / 3600;
    int minutes = seconds / 60;
    int sec = fabs(round((int)seconds % 60));
    NSString *ch = hours <= 9 ? @"0": @"";
    NSString *cm = minutes <= 9 ? @"0": @"";
    NSString *cs = sec <= 9 ? @"0": @"";
    return [NSString stringWithFormat:@"%@%i:%@%i:%@%i", ch, hours, cm, minutes, cs, sec];
}

+ (BOOL) isEmpty:(id) data {
    return data == nil || data == [NSNull null]
    || ([data respondsToSelector:@selector(length)]
        && [data length] == 0)
    || ([data respondsToSelector:@selector(count)]
        && [data count] == 0);
    
}

#pragma mark -
#pragma mark Misc

+ (NSString *) stringByTruncatingToWidth:(NSString *) string width:(CGFloat) width withFont:(UIFont*) font {
    NSString *currentString = @"";
    for (int i = 0; i <= string.length; i++) {
        CGSize currentSize = [currentString sizeWithFont:font];
        if (currentSize.width > width) {
            currentString = [currentString stringByAppendingString:@"..."];
            break;
        }
        currentString = [string substringWithRange:NSMakeRange(0, i)];
    }
    
    return currentString;
}

+ (NSString *) replacePlaceholder:(NSString *) string value:(id) value {
    if (!string) return nil;
    
    NSArray *matches = [_regex matchesInString:string options:NSMatchingReportProgress range:NSMakeRange(0, string.length)];
    
    for (NSTextCheckingResult *match in [matches reverseObjectEnumerator]) {
        NSRange replace = [match rangeAtIndex:0];
        NSRange placeholder = [match rangeAtIndex:1];
        
        NSString *key = [string substringWithRange:placeholder];
        id val = [value valueForKey:key];
        
        if (!val) val = @"";

        string = [string stringByReplacingCharactersInRange:replace withString:[val description]];
    }

    return string;
}

+ (NSString *) replaceEntityPlaceholder:(NSString *) string  block:(NSString * (^)(NSString *key))block   {
    if (!string) return nil;
    
    NSArray *matches = [_regex matchesInString:string options:NSMatchingReportProgress range:NSMakeRange(0, string.length)];
    
    for (NSTextCheckingResult *match in [matches reverseObjectEnumerator]) {
        NSRange replace = [match rangeAtIndex:0];
        NSRange placeholder = [match rangeAtIndex:1];
        
        NSString *key = [string substringWithRange:placeholder];
        NSString *val = block(key);
        
        if (!val) val = @"";
        
        string = [string stringByReplacingCharactersInRange:replace withString:[val description]];
    }
    
    return string;
}

+ (NSString *) generateName:(int) len {
    NSMutableString *randomString = [NSMutableString stringWithCapacity: len];
    for (int i=0; i<len; i++) {
        [randomString appendFormat: @"%C", [letters characterAtIndex: arc4random() % [letters length]]];
    }
    
    return randomString;
}

+ (void) findAllProperties:(Class) bean array:(NSMutableArray *) list {
    Class parent = class_getSuperclass(bean);
    if (parent != [GWSerializable class]) {
        [self findAllProperties:parent array:list];
    }
    
    unsigned int count, i;
    objc_property_t *properties = class_copyPropertyList(bean, &count);
    for (i = 0; i < count; i++) {
        objc_property_t property = properties[i];
        [list addObject:[NSString stringWithCString:property_getName(property) encoding:NSUTF8StringEncoding]];
    }
    free(properties);
}

+ (NSString *) escape:(NSString *) term {
    if (term) {
        return  [(NSString *) CFURLCreateStringByAddingPercentEscapes(
                                                                      NULL, /* allocator */
                                                                      (CFStringRef)term,
                                                                      NULL, /* charactersToLeaveUnescaped */
                                                                      (CFStringRef)@"!*'();:@&=+$,/?%#[]",
                                                                      kCFStringEncodingUTF8) autorelease];
    }
    return nil;
}

+ (id) call:(id) target selector:(SEL) selector args:(void *) arg, ... {
    
    NSMethodSignature *ms = [target methodSignatureForSelector:selector];
    NSInvocation *inv = [NSInvocation invocationWithMethodSignature:ms];
    [inv setTarget:target];
    [inv setSelector:selector];
    if (arg) {
        int index = 2;
        [inv setArgument:arg atIndex:index];
        
        id temp;
        va_list alist;
        va_start(alist, arg);
        
        while ((temp = va_arg(alist, id))){
            index++;
            char argType = [ms getArgumentTypeAtIndex:index][0];
            if (argType == _C_PTR) {
                [inv setArgument:&temp atIndex:index];
            }else{
                [inv setArgument:temp atIndex:index];
            }
        }
        va_end(alist);
        
    }
    
    [inv invoke];
    
    NSObject *returnObject = nil;
    char returnType = ms.methodReturnType[0];
    if(returnType != _C_VOID){
        [inv getReturnValue:&returnObject];
    }
    
    return returnObject;
}

@end