//
//  OFUser.m
//  Prometheus
//
//  Created by Eugene Maystrenko on 6/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "OFUser.h"

@implementation OFUser

- (id) initWithDictionary:(NSDictionary *) dictionary {
    if (self = [super initWithDictionary:dictionary]) {
		self.username = [Util get:dictionary key:@"username"];
        self.firstName = [Util get:dictionary key:@"firstName"];
        self.lastName = [Util get:dictionary key:@"lastName"];
        self.email = [Util get:dictionary key:@"email"];
        self.password = [Util get:dictionary key:@"password"];
        self.avatarResourceLookup = [Util get:dictionary key:@"avatarResourceLookup"];
	}
	return self;
}

- (NSMutableDictionary *) dictionary {
    NSMutableDictionary *dic = [super dictionary];
    
    [Util add:dic value:self.username key:@"username"];
    [Util add:dic value:self.email key:@"email"];
    [Util add:dic value:self.firstName key:@"firstName"];
    [Util add:dic value:self.lastName key:@"lastName"];
    [Util add:dic value:self.password key:@"password"];
    [Util add:dic value:self.avatarResourceLookup key:@"avatarResourceLookup"];
    [Util add:dic value:self.temporaryFile key:@"temporaryFile"];
    
    return dic;
}

- (void) dealloc{
    [_username release];
    [_firstName release];
    [_lastName release];
    [_email release];
    [_password release];
    [_avatarResourceLookup release];
    [_temporaryFile release];
    [super dealloc];
}

@end
