//
//  GWEntity.m
//  Prometheus
//
//  Created by Eugene Maystrenko on 6/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "GWEntity.h"

@implementation GWEntity

- (id) initWithDictionary:(NSDictionary *) dictionary {
    if (self = [super initWithDictionary:dictionary]) {
		self.pk = [Util get:dictionary key:@"id"];
	}
	return self;
}

- (NSMutableDictionary *) dictionary {
    NSMutableDictionary *dic = [super dictionary]; 
    [Util add:dic value:self.pk key:@"id"];    
    return dic;
}

- (BOOL)isEqual:(id) object {
    return [self class] == [object class] && [_pk isEqualToNumber:[object pk]];
}

- (NSUInteger)hash {
    return [_pk hash];
}

- (id)copyWithZone:(NSZone *)zone {
    id copy = [[[self class] allocWithZone:zone] init];
    
    if (copy) {
        [copy setPk:_pk];
    }
    
    return copy;
}

- (NSString *)description {
    return [NSString stringWithFormat:@"pk = %@", _pk];
}

- (void) dealloc {
    [_pk release];
    [super dealloc];
}

@end
