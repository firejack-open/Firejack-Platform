//
//  GWSlideView.h
//  Prometheus
//
//  Created by Eugene on 7/23/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GWSlideCellView.h"
#import "GWAdvancedSearchView.h"
#import "GWEntity.h"

@protocol GWSlideDataSource, GWSlideDelegate;

@interface GWSlideView : UIView<UITableViewDelegate, UITableViewDataSource, GWAdvancedSearchDelegate> {
    UITableView *_tableView;
    GWAdvancedSearchView *_advancedSearchView;
    UIActivityIndicatorView *_indicator;
    NSUInteger _count;
    BOOL _load;
    BOOL _visible;
}

@property (nonatomic, retain) UIView *adjacentView;
@property (nonatomic, assign) id<GWSlideDataSource> dataSource;
@property (nonatomic, assign) id<GWSlideDelegate> delegate;

- (void) show;
- (void) reload;
- (void) deselectAll;
- (void) unselect;

@end

@protocol GWSlideDataSource <NSObject>

- (void) slide:(GWSlideView *) slide term:(NSString *) term offset:(NSNumber *) offset limit:(NSNumber *) limit total:(NSNumber **) total;
- (void) slide:(GWSlideView *) slide cell:(GWSlideCellView *) cell forRow:(NSUInteger) row;
@optional
- (BOOL) slideIsMultipleSelection:(GWSlideView *) slide;
- (BOOL) slide:(GWSlideView *) slide isSelectedRow:(NSUInteger) row;

@end

@protocol GWSlideDelegate <NSObject>
- (void) slide:(GWSlideView *) slide visible:(BOOL) visible;
- (void) slide:(GWSlideView *) slide didSelectForRow:(NSUInteger) row;
@optional
- (void) slide:(GWSlideView *) slide didDeselectForRow:(NSUInteger) row;
@end