//
//  GWSerializable.m
//  Prometheus
//
//  Created by Eugene Maystrenko on 7/4/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "GWSerializable.h"

@implementation GWSerializable

- (id) initWithDictionary:(NSDictionary *) dictionary {
    if (self = [super init]) {
	}
	return self;
}

- (NSMutableDictionary *) dictionary {
    return [NSMutableDictionary dictionary];
}

@end
