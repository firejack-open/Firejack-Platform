//
//  GWKeyValue.m
//  Prometheus
//
//  Created by mjr on 6/5/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWKeyValue.h"

@implementation GWKeyValue

- (id) initWithDictionary:(NSDictionary *) dictionary {
    if (self = [super initWithDictionary:dictionary]) {
		self.key = [Util get:dictionary key:@"key"];
        self.value = [Util get:dictionary key:@"value"];
	}
	return self;
}

- (void)dealloc {
    [_key release];
    [_value release];
    [super dealloc];
}

@end
