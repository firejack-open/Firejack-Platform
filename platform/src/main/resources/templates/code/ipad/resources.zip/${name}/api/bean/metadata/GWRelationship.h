//
//  GWRelationship.h
//  Prometheus
//
//  Created by Администратор on 4/11/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWProperty.h"

@class GWModel;

@interface GWRelationship : GWProperty

@property (nonatomic, retain) NSString *target;
@property (nonatomic, retain) NSString *path;
@property (nonatomic, retain) GWModel *reference;

- (id) displayValue:(id) value;

@end
