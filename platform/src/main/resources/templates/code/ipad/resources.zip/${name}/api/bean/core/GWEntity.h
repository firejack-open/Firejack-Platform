//
//  GWEntity.h
//  Prometheus
//
//  Created by Eugene Maystrenko on 6/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "GWSerializable.h"

@interface GWEntity : GWSerializable<NSCopying> 

@property (nonatomic, retain) NSNumber *pk;

@end
