//
//  GWKeyValue.h
//  Prometheus
//
//  Created by mjr on 6/5/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWSerializable.h"

@interface GWKeyValue : GWSerializable

@property (nonatomic, retain) NSString *key;
@property (nonatomic, retain) NSObject *value;

@end
