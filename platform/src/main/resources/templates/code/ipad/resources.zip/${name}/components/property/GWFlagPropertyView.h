//
//  GWFlagPropertyView.h
//  Prometheus
//
//  Created by mjr on 7/1/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWPropertyView.h"

@interface GWFlagPropertyView : GWPropertyView {
    UIButton *_checkbox;
}

@end
