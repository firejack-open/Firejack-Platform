//
//  GWBlankConstraint.m
//  Prometheus
//
//  Created by mjr on 7/4/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWBlankConstraint.h"

@implementation GWBlankConstraint

- (id)initWithConstraint:(GWRuleParameter *) constraint {
    self = [super initWithConstraint:constraint];
    if (self) {
    }
    return self;
}

- (BOOL) validateValue:(id) value error:(NSString **) message {
    if (![value isKindOfClass:[NSString class]] || [value length] == 0) {
         *message = self.error;
    }
    return *message == nil;
}

@end
