//
//  GWTextFieldView.m
//  Prometheus
//
//  Created by Eugene Maystrenko on 8/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "GWTextFieldView.h"

@implementation GWTextFieldView

- (id) init {
    return [super init];
}

- (CGRect) leftViewRectForBounds:(CGRect)bounds {
    return _leftIcon;
}

- (CGRect)rightViewRectForBounds:(CGRect) bounds {
    return _rightIcon;
}

- (CGRect)textRectForBounds:(CGRect)bounds {
    return CGRectInset( bounds , _dx , _dy);
}

- (CGRect)placeholderRectForBounds:(CGRect)bounds {
    return CGRectInset( bounds , _dx , _dy);
}

- (CGRect)editingRectForBounds:(CGRect)bounds {
    return CGRectInset( bounds , _dx , _dy);
}

@end
