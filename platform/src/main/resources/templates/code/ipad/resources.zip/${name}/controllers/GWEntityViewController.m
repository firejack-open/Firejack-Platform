//
//  GWEntityViewController.m
//  Prometheus
//
//  Created by mjr on 7/15/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWEntityViewController.h"

@implementation GWEntityViewController

- (id)initWithModel:(GWModel *)model {
    self = [super init];
    if (self) {
        _model = [model retain];
    }
    return self;
}

- (void)dealloc {
    [_parent release];
    [_parentProperty release];
    [_queryParameters release];
    [_sortOrder release];
    [_model release];
    [super dealloc];
}

@end
