//
//  GWEnum.h
//  Prometheus
//
//  Created by mjr on 6/3/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "GWSerializable.h"

@interface GWEnum : GWSerializable<NSCoding>

@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSString *display;
@property (nonatomic, retain) NSString *description;

- (BOOL)isEqualToAnEnum:(GWEnum *)anEnum;


@end
