//
//  GWTextPropertyView.m
//  Prometheus
//
//  Created by mjr on 6/26/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWTextPropertyView.h"

@implementation GWTextPropertyView

- (id) initWithFrame:(CGRect) frame property:(GWProperty *) property {
    self = [super initWithFrame:RectSetHeight(frame, 115) property:property];
    if (self) {
        _textView = [[UITextView alloc] initWithFrame:CGRectMake(0, 25, 625, 90)];
        _textView.delegate = self;
        _textView.font = [UIFont fontWithName:@"HelveticaNeue" size:20];
        _textView.textColor = UIColorFromHex(0x478ACC);
        _textView.backgroundColor = UIColorFromHex(0xF2FCFF);
        _textView.autocapitalizationType = UITextAutocapitalizationTypeNone;
        _textView.autocorrectionType = UITextAutocorrectionTypeNo;
        _textView.returnKeyType = UIReturnKeyDone;
        _textView.layer.cornerRadius = 5;
        _textView.layer.shadowColor = UIColorFromHex(0xE6EEF2).CGColor;
        _textView.layer.shadowOffset = CGSizeMake(0, 1);
        _textView.layer.borderColor = UIColorFromHex(0xC2C8CC).CGColor;
        _textView.layer.borderWidth = 1;
        if ([Util isIOS7]) {
            _textView.textContainerInset = UIEdgeInsetsMake(18, 12, 18, 12);
        }
        if (property.type == GWPropertyTypeNumber)
            _textView.keyboardType = UIKeyboardTypeNumberPad;
        [self addSubview:_textView];
        [_textView release];
    }
    return self;
}

- (void)setSelected:(BOOL) selected {
    if (selected) {
        _textView.layer.borderColor = UIColorFromHex(0x828F99).CGColor;
        _textView.backgroundColor = [UIColor whiteColor];
        _textView.layer.borderWidth = 2;
    } else {
        _textView.layer.borderColor = UIColorFromHex(0xC2C8CC).CGColor;
        _textView.backgroundColor = UIColorFromHex(0xF2FCFF);
        _textView.layer.borderWidth = 1;
    }
    
    [super setSelected:selected];
}

- (BOOL) valid {
    BOOL valid = [super valid];
    if (!valid) {
        _textView.layer.borderColor = UIColorFromHex(0xBD3700).CGColor;
    }
    return valid;
}

- (BOOL)textViewShouldBeginEditing:(UITextView *)textField {
    return _property.attribute == GWPropertyAttributeDefault;
}

- (void)textViewDidBeginEditing:(UITextView *)textField {
    self.selected = YES;
}

- (void)textViewDidEndEditing:(UITextView *)textField {
    [_property setStringValue:textField.text forObject:self.entity];
    self.selected = NO;
}

- (void) prepare {
    [super prepare];
    if (_property.type != GWPropertyTypeList)
        _textView.text = [_property stringValue:self.entity];
}

@end
