//
//  Util.h
//  Prometheus
//
//  Created by Eugene Maystrenko on 6/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#import "GWEnum.h"

@interface Util : NSObject 

+ (BOOL) isIOS5;
+ (BOOL) isIOS6;
+ (BOOL) isIOS7;
+ (BOOL) isNumber:(NSString *) string;
+ (void) add:(NSMutableDictionary *) dic value:(id) value key:(NSString *) key;
+ (void) addList:(NSMutableDictionary *) dic list:(NSArray *) list key:(NSString *) key;
+ (id) getList:(NSDictionary *) dic key:(NSString *)key bean:(Class) bean;
+ (id) get:(NSDictionary *) dic key:(NSString *) key;
+ (id) getObject:(NSDictionary *) dic key:(NSString *) key bean:(Class) bean;
+ (NSDate *) getDate:(NSDictionary *) dic key:(NSString *) key;
+ (void) addDate:(NSMutableDictionary *) dic date:(NSDate *) date key:(NSString *) key;
+ (GWEnum *) getEnum:(NSDictionary *) dic key:(NSString *) key;
+ (void) addEnum:(NSMutableDictionary *) dic value:(GWEnum *) value key:(NSString *) key;
+ (BOOL) getBool:(NSDictionary *) dic key:(NSString *) key;
+ (void) addBool:(NSMutableDictionary *) dic value:(BOOL) value key:(NSString *) key;

+ (NSString *) append:(id) first, ... ;
+ (NSString *) serialize:(id) data ;
+ (NSDictionary *) deserialize:(NSString *)string;

+ (void)setProperty:(NSString *)key value:(id) value;
+ (void)setBoolProperty:(NSString *)key value:(BOOL) value;
+ (void)removeProperty:(NSString *) key;
+ (NSString *)getProperty:(NSString *) key;
+ (BOOL)getBoolProperty:(NSString *) key;

+ (NSString *) timeFormat: (float) seconds;
+ (BOOL) isEmpty:(id) data;
+ (NSString*) stringByTruncatingToWidth:(NSString *) string width:(CGFloat) width withFont:(UIFont*) font;
+ (NSString *) generateName:(int) len;

+ (NSDate *) dateFromString:(NSString *) value;
+ (NSString *) stringFromDate:(NSDate *) date;
+ (NSDate *) timeFromString:(NSString *) value;
+ (NSString *) stringFromTime:(NSDate *) date;
+ (NSDate *) fullTimeFromString:(NSString *) value;
+ (NSString *) stringFromFullTime:(NSDate *) date;

+ (void) findAllProperties:(Class) bean array:(NSMutableArray *) list;

+ (NSString *) replacePlaceholder:(NSString *) string value:(id) value;
+ (NSString *) replaceEntityPlaceholder:(NSString *) string  block:(NSString * (^)(NSString *key))block;
+ (NSString *) escape:(NSString *) term;
+ (id) call:(id) target selector:(SEL) selector args:(void *) arg, ...;

@end