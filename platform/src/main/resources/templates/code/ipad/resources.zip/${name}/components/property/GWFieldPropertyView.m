//
//  GWFieldPropertyView.m
//  Prometheus
//
//  Created by mjr on 6/27/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWFieldPropertyView.h"

@implementation GWFieldPropertyView

- (id) initWithFrame:(CGRect) frame property:(GWProperty *) property {
    self = [super initWithFrame:RectSetHeight(frame, 75) property:property];
    if (self) {
        _textFieldView = [[GWTextFieldView alloc] initWithFrame:CGRectMake(0, 25, 625, 50)];
        _textFieldView.delegate = self;
        _textFieldView.font = [UIFont fontWithName:@"HelveticaNeue" size:20];
        _textFieldView.placeholder = property.display;
        _textFieldView.dx = 18;
        _textFieldView.dy = 12;
        _textFieldView.textColor = UIColorFromHex(0x478ACC);
        _textFieldView.backgroundColor = UIColorFromHex(0xF2FCFF);
        _textFieldView.autocapitalizationType = UITextAutocapitalizationTypeNone;
        _textFieldView.autocorrectionType = UITextAutocorrectionTypeNo;
        _textFieldView.returnKeyType = UIReturnKeyDone;
        _textFieldView.layer.cornerRadius = 5;
        _textFieldView.layer.shadowColor = UIColorFromHex(0xE6EEF2).CGColor;
        _textFieldView.layer.shadowOffset = CGSizeMake(0, 1);
        _textFieldView.layer.borderColor = UIColorFromHex(0xC2C8CC).CGColor;
        _textFieldView.layer.borderWidth = 1;
        if (property.type == GWPropertyTypeNumber)
            _textFieldView.keyboardType = UIKeyboardTypeNumberPad;
        if (property.attribute != GWPropertyAttributeReadOnly)
            _textFieldView.clearButtonMode = UITextFieldViewModeAlways;
        [self addSubview:_textFieldView];
        [_textFieldView release];
    }
    return self;
}

- (void)setSelected:(BOOL) selected {
    if (selected) {
        _textFieldView.layer.borderColor = UIColorFromHex(0x828F99).CGColor;
        _textFieldView.backgroundColor = [UIColor whiteColor];
        _textFieldView.layer.borderWidth = 2;
    } else {
        _textFieldView.layer.borderColor = UIColorFromHex(0xC2C8CC).CGColor;
        _textFieldView.backgroundColor = UIColorFromHex(0xF2FCFF);
        _textFieldView.layer.borderWidth = 1;
    }
    
    [super setSelected:selected];
}

- (BOOL) validate {
    BOOL valid = [super valid];
    if (!valid) {
         _textFieldView.layer.borderColor = UIColorFromHex(0xBD3700).CGColor;
    }
    return valid;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    return _property.attribute == GWPropertyAttributeDefault;
}

- (void)textFieldDidBeginEditing:(UITextField *)textField {
    self.selected = YES;
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    [_property setStringValue:textField.text forObject:self.entity];
    self.selected = NO;
}

- (BOOL)textFieldShouldClear:(UITextField *)textField {
    [_property setValue:nil forObject:self.entity];
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField {
    return [textField resignFirstResponder];
}

- (void) prepare {
    [super prepare];
    if (_property.type != GWPropertyTypeList)
        _textFieldView.text = [_property stringValue:self.entity];
}

@end
