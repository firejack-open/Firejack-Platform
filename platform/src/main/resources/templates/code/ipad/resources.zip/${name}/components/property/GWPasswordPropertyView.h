//
//  GWPasswordPropertyView.h
//  Prometheus
//
//  Created by mjr on 6/27/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWFieldPropertyView.h"

@interface GWPasswordPropertyView : GWFieldPropertyView

@end
