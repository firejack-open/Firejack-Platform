//
//  ModelManager.h
//  Prometheus
//
//  Created by Администратор on 3/29/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "API.h"
#import "GWModel.h"
#import "GWProperty.h"
#import "GWPropertyRule.h"
#import "GWRelationship.h"
#import "GWConstraint.h"
#import "GWEnumConstraint.h"
#import "GWLengthConstraint.h"
#import "GWMatchConstraint.h"
#import "GWBlankConstraint.h"
#import "GWNullConstraint.h"
#import "GWMenuItem.h"

@interface ModelManager : NSObject<NSCoding>

@property (nonatomic, retain) NSMutableDictionary *data;

+ (ModelManager *) manager;

- (GWModel *) model:(NSString *) lookup;
- (void) loadRules;
- (void) persist;

@end
