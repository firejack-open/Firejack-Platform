//
//  GWCarouselView.m
//  Prometheus
//
//  Created by Администратор on 2/28/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWCarouselView.h"

#define WIDTH 204.8
#define HEIGHT 330
#define PADDING 1

@implementation GWCarouselView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        height = ViewHeight(self);
        center = ViewWidth(self) /2 - WIDTH/2;
        
        self.contentInset = UIEdgeInsetsMake(0, center, 0, center);
        self.showsVerticalScrollIndicator = NO;
        self.showsHorizontalScrollIndicator = NO;
        self.delegate = self;
    }
    return self;
}

- (void) reload {
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    select = nil;
    
    NSUInteger count = 0;
    if ([_dataSource respondsToSelector:@selector(numberOfItemsInCarousel:)]) {
        count = [_dataSource numberOfItemsInCarousel:self];
    }
    
    [self setContentSize:CGSizeMake((WIDTH + PADDING) * count, HEIGHT)];
    
    CGFloat indentation = height/2 - HEIGHT/2;
    for (NSUInteger i = 0; i < count; i++) {
        CGRect frame = CGRectMake(i * (WIDTH + PADDING), indentation, WIDTH, HEIGHT);
        
        UIControl *cell = [[UIControl alloc] initWithFrame:frame];
        cell.tag = i;
        
        if (i == 0) {
            cell.transform = CGAffineTransformMakeScale(1.2, 1.2);
            cell.alpha = 1;
        } else {
            cell.transform = CGAffineTransformMakeScale(1, 1);
            cell.alpha = 0.5;
            
            UIImageView *devider = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"m_devider"]];
            devider.frame = CGRectMake(i * (WIDTH + PADDING), indentation, 1, HEIGHT);
            [self addSubview:devider];
            [devider release];
        }
        
        if ([_dataSource respondsToSelector:@selector(carousel:index:view:)]) {
            [_dataSource carousel:self index:i view:cell];
        }
        
        [cell addTarget:self action:@selector(select:) forControlEvents:UIControlEventTouchUpInside];
        
        [self addSubview:cell];
        [cell release];
    }
}

- (void)scrollViewDidScroll:(UIScrollView *) sender {
    CGPoint point = CGPointMake(self.contentOffset.x + center, height/2);
    for (UIView *subview in self.subviews) {
        if (select != subview && CGRectContainsPoint(subview.frame, point)) {
            subview.transform = CGAffineTransformMakeScale(1.2, 1.2);
            subview.alpha = 1;
            select.transform = CGAffineTransformMakeScale(1, 1);
            select.alpha = 0.5;
            select = subview;
        }
    }
}

- (void) select:(UIControl *) sender {
    CGFloat alpha = sender.alpha;
    CGAffineTransform transform = sender.transform;
    
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseIn
                     animations:^{
                         sender.transform = CGAffineTransformMakeScale(2, 2);
                         sender.alpha = 0;
                     }
                     completion:^(BOOL finished){
                         sender.transform = transform;
                         sender.alpha = alpha;
                         if ([_carouselDelegate respondsToSelector:@selector(carousel:didSelectAtIndex:)]) {
                             [_carouselDelegate carousel:self didSelectAtIndex:sender.tag];
                         }
                     }];
}

- (void) dealloc {
    [super dealloc];
}

@end
