//
//  GWPropertyView.m
//  Prometheus
//
//  Created by mjr on 6/25/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWPropertyView.h"

@implementation GWPropertyView

- (id)initWithFrame:(CGRect)frame property:(GWProperty *) property {
    self = [super initWithFrame:frame];
    if (self) {
        _property = [property retain];
        
        _labelView = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, RectWidth(frame), 20)];
        _labelView.font = [UIFont fontWithName:@"HelveticaNeue-Bold" size:20];
        _labelView.textColor = UIColorFromHex(0x98A7B2);
        _labelView.shadowColor = UIColorFromHex(0xE6EEF2);
        _labelView.shadowOffset = CGSizeMake(0, 1);
        _labelView.backgroundColor = [UIColor clearColor];
        [self addSubview:_labelView];
        [_labelView release];
        
        _info = [[UIButton alloc] initWithFrame:CGRectMake(640, (RectHeight(frame) - 25)/2 + 11.5, 27, 27)];
        [_info setBackgroundImage:[UIImage imageNamed:@"f_info"] forState:UIControlStateNormal];
        [_info addTarget:self action:@selector(showInfo:) forControlEvents:UIControlEventTouchUpInside];
        _info.backgroundColor = [UIColor clearColor];
        _info.hidden = YES;
        [self addSubview:_info];
        [_info release];
        
        _popup = [[GWAlertView alloc] initWithFrame:CGRectZero];
        [self addSubview:_popup];
        [_popup release];
    }
    return self;
}

- (void) setSelected:(BOOL) selected {
    [super setSelected:selected];
    if (selected) {
        _info.hidden = YES;
        [_popup hide];
        _labelView.textColor = UIColorFromHex(0x6C7780);
        [self sendActionsForControlEvents:UIControlEventEditingDidBegin];
    } else {
        _labelView.textColor = UIColorFromHex(0x98A7B2);
        [self sendActionsForControlEvents:UIControlEventEditingDidEndOnExit];
        [self valid];
    }
}

- (BOOL) valid {
    _error = nil;
    for (GWConstraint *constraint in _property.constraints) {
        if (![constraint validateValue:[self value] error:&_error]) {
            _labelView.textColor = UIColorFromHex(0xBD3700);
            break;
        }
    }
    
    BOOL valid = _error == nil;
    _info.hidden = valid;
    
    return valid;
}

- (void) showInfo:(id) sender {
    [_popup show:_error inView:sender];
}

- (void) prepare {
    [self bringSubviewToFront:_popup];
    
    if (_label)
        _labelView.text = _label;
    else
        _labelView.text = _property.display;
}

- (void) prePersist {
}

- (GWPropertyType) propertyType {
    return _property.type;
}

- (SEL) referenceSelectorByType:(GWActionType) type {
    if ([_property isKindOfClass:[GWRelationship class]]){
        GWRelationship *relationship = (GWRelationship *) _property;
        return [relationship.reference findSelectorByType:type];
    }
    return nil;
}

- (NSString *) referencePath {
    if ([_property isKindOfClass:[GWRelationship class]]) {
        GWRelationship *relationship = (GWRelationship *) _property;
        return relationship.path;
    }
    return nil;
}

- (id) value {
    return [_property value:_entity];
}

- (void) setValue:(id) value {
    [_property setValue:value forObject:_entity];
}

- (void) removeObject:(id) value {
    [_property setValue:nil forObject:_entity];
}

- (id) referenceHeading:(id) value {
    if ([_property isKindOfClass:[GWRelationship class]])
        return [[(GWRelationship *) _property reference] headingValue:value];
    return nil;
}

- (id) referenceSubHeading:(id) value {
    if ([_property isKindOfClass:[GWRelationship class]])
        return [[(GWRelationship *) _property reference] subHeadingValue:value];
    return nil;
}

- (id) referenceDescription:(id) value {
    if ([_property isKindOfClass:[GWRelationship class]])
        return [[(GWRelationship *) _property reference] descriptionValue:value];
    return nil;
}

- (void)dealloc {
    [_label release];
    [_entity release];
    [_error release];
    [_property release];
    [_sliderView release];
    [_mainView release];
    [super dealloc];
}
@end
