//
//  GWGridCellView.m
//  Prometheus
//
//  Created by Администратор on 3/22/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWGridCellView.h"

@implementation GWGridCellView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {        
    }
    return self;
}

- (void) setSelected:(BOOL)selected {
    super.selected = selected;
    _selectedLayer.hidden = !selected;
}

- (void)setRow:(NSInteger)row {
    _row = row;
    _backgroundLayer.hidden = row % 2 == 1;
}

- (void)dealloc {
    [_backgroundLayer release];
    [_selectedLayer release];
    [super dealloc];
}

@end
