//
//  GWEnumConstraint.m
//  Prometheus
//
//  Created by mjr on 7/3/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWEnumConstraint.h"

@implementation GWEnumConstraint

- (id)initWithConstraint:(GWRuleParameter *) constraint {
    self = [super initWithConstraint:constraint];
    if (self) {
        if (constraint.parameters) {
            NSMutableArray *values = [NSMutableArray array];
            for (GWKeyValue *entry in constraint.parameters) {
                if ([entry.key isEqualToString:@"values"]) {
                    NSArray *enums = (NSArray *) entry.value;
                    for (NSArray *value in enums) {
                        GWEnum *e = [[GWEnum alloc] init];
                        e.name = value[0];
                        e.display = value[1];
                        
                        [values addObject:e];
                        [e release];
                    }
                }
            }
            self.values = values;
        }
    }
    return self;
}

- (id)initWithCoder:(NSCoder *) decoder {
    if (self = [super initWithCoder:decoder]) {
        self.values = [decoder decodeObjectForKey:@"values"];
    }
    return self;
}

- (void) encodeWithCoder:(NSCoder *) coder {
    [super encodeWithCoder:coder];
    
    [coder encodeObject:_values forKey:@"values"];
}

- (BOOL) validateValue:(id) value error:(NSString **) message {
    BOOL contains = [_values containsObject:value];
    if (!contains) {
         *message = self.error;
    }
    return contains;
}

- (void)dealloc {
    [_values release];
    [super dealloc];
}

@end
