//
//  Error.h
//  Prometheus
//
//  Created by Eugene Maystrenko on 8/14/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "GWEntity.h"

@interface GWServerError : GWEntity

@property (nonatomic, retain) NSString *name;
@property (nonatomic, retain) NSString *msg;

@end
