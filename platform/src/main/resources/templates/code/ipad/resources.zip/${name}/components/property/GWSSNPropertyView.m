//
//  GWSSNPropertyView.m
//  Prometheus
//
//  Created by mjr on 7/1/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWSSNPropertyView.h"

@implementation GWSSNPropertyView

- (id) initWithFrame:(CGRect) frame property:(GWProperty *) property {
    self = [super initWithFrame:RectSetHeight(frame, 75) property:property];
    if (self) {
        _textFieldView.keyboardType = UIKeyboardTypePhonePad;
        _regex = [[NSRegularExpression alloc] initWithPattern:@"(\\d{0,3})?+(\\d{1,2})?+(\\d{1,4})?" options:NSRegularExpressionCaseInsensitive error:nil];
    }
    return self;
}


- (void)textFieldDidBeginEditing:(UITextField *)textField {
    [super textFieldDidBeginEditing:textField];
}

- (void)textFieldDidEndEditing:(UITextField *)textField {
    [super textFieldDidEndEditing:textField];
}

- (BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string {
    NSString *text = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    text = [text stringByReplacingOccurrencesOfString:@"\\D" withString:@"" options:NSRegularExpressionSearch range:NSMakeRange(0, text.length)];
    
    NSArray *matches = [_regex matchesInString:text options:NSMatchingReportProgress range:NSMakeRange(0, text.length)];
    
    if ([matches count] != 0) {
        NSTextCheckingResult *match = matches[0];
        
        NSRange code1 = [match rangeAtIndex:1];
        NSRange code2 = [match rangeAtIndex:2];
        NSRange code3 = [match rangeAtIndex:3];
        
        if (code3.location != NSNotFound) {
            NSString *match1 = [text substringWithRange:code1];
            NSString *match2 = [text substringWithRange:code2];
            NSString *match3 = [text substringWithRange:code3];
            
            textField.text = [NSString stringWithFormat:@"%@-%@-%@", match1, match2, match3];
        } else if (code2.location != NSNotFound) {
            NSString *match1 = [text substringWithRange:code1];
            NSString *match2 = [text substringWithRange:code2];
            
            textField.text = [NSString stringWithFormat:@"%@-%@", match1, match2];
        } else if (code1.location != NSNotFound) {
            NSString *match1 = [text substringWithRange:code1];
            
            textField.text = [NSString stringWithFormat:@"%@", match1];
        }
    }
    
    return NO;
}

- (void)dealloc {
    [_regex release];
    [super dealloc];
}

@end
