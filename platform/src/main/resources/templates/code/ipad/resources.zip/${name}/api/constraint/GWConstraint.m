//
//  GWConstraint.m
//  Prometheus
//
//  Created by mjr on 7/3/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWConstraint.h"

@implementation GWConstraint

- (id)initWithConstraint:(GWRuleParameter *) constraint {
    self = [super init];
    if (self) {
        self.error = constraint.errorMessage;
    }
    return self;
}

- (id)initWithCoder:(NSCoder *) decoder {
    if (self = [super init]) {
        self.error = [decoder decodeObjectForKey:@"error"];
    }
    return self;
}

- (void) encodeWithCoder:(NSCoder *) coder {
    [coder encodeObject:_error forKey:@"error"];
}

- (BOOL) validateValue:(id) value error:(NSString **) message {
    return YES;
}

@end
