//
//  OFLookup.m
//  Prometheus
//
//  Created by Eugene Maystrenko on 7/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "OFLookup.h"

@implementation OFLookup

- (id) initWithDictionary:(NSDictionary *) dictionary {
    if (self = [super initWithDictionary:dictionary]) {
		self.name = [Util get:dictionary key:@"name"];
        self.path = [Util get:dictionary key:@"path"];
        self.lookup = [Util get:dictionary key:@"lookup"];
        self.type = [Util get:dictionary key:@"type"];
        self.info = [Util get:dictionary key:@"description"];       
	}
	return self;
}

- (NSMutableDictionary *) dictionary {
    NSMutableDictionary *dic = [super dictionary];
    
    [Util add:dic value:self.name key:@"name"];
    [Util add:dic value:self.path key:@"path"];
    [Util add:dic value:self.lookup key:@"lookup"];
    [Util add:dic value:self.info key:@"description"];
    
    return dic;
}


- (void) dealloc {
    [_name release];
    [_path release];
    [_lookup release];
    [_type release];
    [_info release];
    [super dealloc];
}

@end
