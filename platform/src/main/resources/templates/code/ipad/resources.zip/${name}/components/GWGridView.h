//
//  Util.m
//  Prometheus
//
//  Created by Eugene Maystrenko on 3/20/13.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GWGridCellView.h"
#import "GWPagingView.h"

@protocol GWGridDataSource, GWGridDelegate;

typedef struct _GWState {
    CGFloat x;
    CGFloat width;
} GWState;

NS_INLINE GWState GWMakeState(CGFloat x, CGFloat width) {
    GWState state;
    state.x = x;
    state.width = width;
    return state;
}

@interface GWGridView : UIView<UIScrollViewDelegate> {
    UIScrollView *_scrollView;
    GWPagingView *_paging;
    NSMutableArray *_states;
    CGSize _area;
    NSUInteger _selectColumn;
    NSUInteger _selectRow;
    CGFloat _selectDelta;

    NSMutableArray *_headers;
    NSMutableArray *_columns;
    NSMutableArray *_rows;
    NSMutableSet *_cellPool;
}

@property (nonatomic, retain) NSNumber *total;
@property (nonatomic, retain) NSNumber *limit;

@property (nonatomic, readonly) GWGridCellView *selectCell;

@property (nonatomic, assign) id<GWGridDataSource> dataSource;
@property (nonatomic, assign) id<GWGridDelegate, GWPagingDelegate> delegate;

- (void)reloadData;
- (void) refresh;
- (GWGridCellView *) dequeueReusableCell;

@end

@interface NSValue (NSValueSateExtensions)

+ (NSValue *) valueWithGWSate:(GWState) state;
- (GWState) stateValue;

@end

@protocol GWGridDataSource <NSObject>

- (NSInteger) numberOfColumns:(GWGridView *)gridView;
- (NSInteger) numberOfRow:(GWGridView *)gridView;
- (GWGridCellView *) view:(GWGridView *)gridView viewFoRow:(NSInteger) row column:(NSInteger) column;
- (void) header:(GWGridView *) gridView view:(UIView *) view column:(NSInteger) column;
- (CGFloat) headerHeight:(GWGridView *) gridView;
- (CGFloat) cellHeight:(GWGridView *) gridView;
@optional
- (BOOL) columnResizible:(GWGridView *) gridView atColumn:(NSUInteger) column total:(NSUInteger) total;
- (CGFloat) cellWidth:(GWGridView *) gridView atColumn:(NSUInteger) column;
@end

@protocol GWGridDelegate <NSObject>
@optional
- (void) selectCell:(GWGridView *) gridView atRow:(NSUInteger) row atColumn:(NSUInteger) column;
- (void) selectCell:(GWGridView *) gridView atCell:(GWGridCellView *) cell;
@end