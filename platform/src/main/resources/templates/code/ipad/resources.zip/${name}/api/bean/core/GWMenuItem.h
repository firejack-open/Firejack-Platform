//
//  GWMenuItem.h
//  Prometheus
//
//  Created by Администратор on 3/5/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWSerializable.h"

@interface GWMenuItem : GWSerializable

@property (nonatomic, retain) NSString *title;
@property (nonatomic, retain) NSString *entity;
@property (nonatomic, retain) NSString *type;
@property (nonatomic, assign) GWMenuItem *parent;
@property (nonatomic, retain) NSArray  *items;

@property (nonatomic, retain) UIButton *button;

@end
