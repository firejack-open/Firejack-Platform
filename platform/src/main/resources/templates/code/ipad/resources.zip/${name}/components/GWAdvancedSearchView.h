//
//  GWAdvancedSearchView.h
//  Prometheus
//
//  Created by mjr on 7/29/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GWTextFieldView.h"

@protocol GWAdvancedSearchDelegate;

@interface GWAdvancedSearchView : UIView<UITextFieldDelegate> {
    GWTextFieldView *_searchFieldView;
    NSUInteger _offset;
}

@property (nonatomic, retain) NSString *text;
@property (nonatomic, retain) NSNumber *limit;
@property (nonatomic, retain) NSNumber *total;

@property (nonatomic, assign) id<GWAdvancedSearchDelegate> delegate;

- (void) reload;
- (void) next;

@end

@protocol GWAdvancedSearchDelegate <NSObject>

- (void) search:(GWAdvancedSearchView *) search offset:(NSNumber *)offset limit:(NSNumber *) limit;
@optional
- (void) search:(GWAdvancedSearchView *) search edit:(BOOL) edit;
@end