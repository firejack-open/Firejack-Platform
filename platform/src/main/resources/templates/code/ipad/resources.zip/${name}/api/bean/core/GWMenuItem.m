//
//  GWMenuItem.m
//  Prometheus
//
//  Created by Администратор on 3/5/13.
//  Copyright (c) 2013 mjr. All rights reserved.
//

#import "GWMenuItem.h"

@implementation GWMenuItem

- (id) initWithDictionary:(NSDictionary *) dictionary {
    if (self = [super initWithDictionary:dictionary]) {
        self.title = [Util get:dictionary key:@"title"];
        self.entity = [Util get:dictionary key:@"entity"];
        self.type = [Util get:dictionary key:@"type"];
        self.items = [Util getList:dictionary key:@"items" bean:[GWMenuItem class]];
        if (_items) {
            for (GWMenuItem *item in _items) {
                item.parent = self;
            }
        }
	}
	return self;
}

- (void) dealloc {
    _parent = nil;
    [_title release];
    [_entity release];
    [_type release];
    [_items release];
    [_button release];
    [super dealloc];
}

@end
