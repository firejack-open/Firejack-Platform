//
//  GWBaseViewController.h
//  Prometheus
//
//  Created by Eugene Maystrenko on 6/20/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "API.h"
#import "AppDelegate.h"

@interface GWBaseViewController : UIViewController<APIDelegate>

@property (nonatomic, retain) AppDelegate *delegate;
@property (nonatomic, retain) API *api;

- (IBAction) back:(id)sender;

@end
