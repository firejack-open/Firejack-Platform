//
//  GWRequest.m
//  Prometheus
//
//  Created by Eugene Maystrenko on 7/5/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import "GWRequest.h"

@implementation GWRequest

- (id) initWithDictionary:(NSDictionary *) dictionary {
    if (self = [super initWithDictionary:dictionary]) {
	}
	return self;
}

- (NSMutableDictionary *) dictionary {
    NSMutableDictionary *dic = [super dictionary];
    
    [Util add:dic value:[self.data dictionary] key:@"data"];
    
    return dic;
}

- (void) dealloc {
    [_data release];
    [super dealloc];
}

@end
